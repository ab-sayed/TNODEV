%% For TIRA OA methods only 

% function plot_reachable_sets()
%     %% Initialization
%     close all;
%     % % Generate 4 unique colors using HSV with distinct hues
%     % num_combinations = 4; % 2 approaches x 2 methods
%     % hues = linspace(0, 1, num_combinations + 1); % Spread hues evenly
%     % colors = hsv2rgb([hues(1:end-1)', ones(num_combinations, 1)*0.8, ones(num_combinations, 1)*0.9]);
% 
%     % Define specific colors: red, green, blue, magenta
%     colors = [1, 0, 0;  % Red
%               0, 1, 0;  % Green
%               0, 0, 1;  % Blue
%               1, 0, 1]; % Magenta
%     % Assign colors to combinations: [init_mix, incr_mix, init_samp, incr_samp]
%     color_map = containers.Map({'initial_CT Mixed-Monotonicity', 'incremental_CT Mixed-Monotonicity', ...
%                                'initial_CT Sampled-Data Mixed-Monotonicity', 'incremental_CT Sampled-Data Mixed-Monotonicity'}, ...
%                               mat2cell(colors, ones(1, 4))); % Use  mat2cell(colors, ones(1, num_combinations)) for the case of generating colors
% 
%     method_names = {'CT Mixed-Monotonicity', 'CT Sampled-Data Mixed-Monotonicity'};
% 
%     %% Load data from multiple runs
%     files = dir('reachability_data_sys*.mat');
%     if isempty(files)
%         error('No reachability data files found. Run the main script first.');
%     end
% 
%     all_succ_low = {};
%     all_succ_up = {};
%     all_rand_succ = {};
%     all_t_points = {};
%     all_methods = {};
%     all_n_x = [];
%     all_n_methods = [];
% 
%     for i = 1:length(files)
%         data = load(files(i).name);
%         all_succ_low{end+1} = data.succ_low_all_methods;
%         all_succ_up{end+1} = data.succ_up_all_methods;
%         all_rand_succ{end+1} = data.rand_succ;
%         all_t_points{end+1} = data.t_points;
%         all_methods{end+1} = data.methods;
%         all_n_x(end+1) = data.n_x;
%         all_n_methods(end+1) = data.n_methods;
%     end
% 
%     % Verify consistency
%     if length(unique(all_n_x)) > 1 || length(unique(all_n_methods)) > 1
%         warning('Inconsistent state or method dimensions across files. Using first file''s dimensions.');
%     end
%     n_x = all_n_x(1);
%     n_methods = all_n_methods(1);
% 
%     %% Plotting
%     if n_x == 5
%         plot_pairs = [1 2; 3 4; 4 5];
%         % For spiral use only 2 dimensions, uncomment if needed
%         % if n_x == 2
%         %     plot_pairs = [1 2];
%         % end
% 
%         for i = 1:size(plot_pairs, 1)
%             figure;
%             hold on;
%             grid on;
%             idx1 = plot_pairs(i, 1);
%             idx2 = plot_pairs(i, 2);
% 
%             % Plot random successors from all runs
%             for j = 1:length(all_rand_succ)
%                 scatter(all_rand_succ{j}(idx1, :), all_rand_succ{j}(idx2, :), 5, 'k', 'filled');
%             end
% 
%              % Plot last reachable sets for each file
%             handles = [];
%             proxy_handles = [];
%             legends = {};
%             for j = 1:length(files)
%                 approach = regexp(files(j).name, '_(initial|incremental)_', 'tokens');
%                 approach = approach{1}{1};
%                 file_methods = all_methods{j}; % Methods from the current file
%                 for m = 1:length(method_names) % Iterate over expected methods
%                     method_value = find(file_methods == m + 2); % Adjust for method indices (3 and 4)
%                     if ~isempty(method_value)
%                         method_idx = method_value(1); % Take the first match
%                         k = length(all_t_points{j}); % Last time step
%                         x_min = all_succ_low{j}(idx1, k, method_idx);
%                         y_min = all_succ_low{j}(idx2, k, method_idx);
%                         width = all_succ_up{j}(idx1, k, method_idx) - x_min;
%                         height = all_succ_up{j}(idx2, k, method_idx) - y_min;
%                         key = sprintf('%s_%s', approach, method_names{m});
%                         color = color_map(key);
%                         line_width = 2; % ine width for all the boxes 
%                         if strcmp(key, 'incremental_CT Mixed-Monotonicity')
%                             line_width = 4; % Special Thicker line for green box (incremental_CT Mixed-Monotonicity)
%                         end
%                         h = rectangle('Position', [x_min, y_min, width, height], ...
%                                       'EdgeColor', color, 'LineWidth', line_width, 'LineStyle', '-');
%                         handles = [handles, h];
%                         % Create proxy handle for legend with matching line width
%                         h_proxy = plot(nan, nan, 'Color', color, 'LineWidth', line_width, 'LineStyle', '-', 'Visible', 'off');
%                         proxy_handles = [proxy_handles, h_proxy];
%                         legends{end+1} = sprintf('%s (%s)', method_names{m}, approach);
%                     end
%                 end
%             end
% 
%             % Add labels and legend
%             xlabel(['$x_', num2str(idx1), '$'], 'Interpreter', 'Latex', 'FontSize', 20);
%             ylabel(['$x_', num2str(idx2), '$'], 'Interpreter', 'Latex', 'FontSize', 20);
%             title(['$x_', num2str(idx1), '$ vs. $x_', num2str(idx2), '$'], 'Interpreter', 'Latex', 'FontSize', 16);
%             legend(proxy_handles, legends, 'Location', 'southeast');
%             hold off;
%         end
%     else
%         warning('Plotting is set up only for systems with 5 states.');
%     end
% end


%% For TIRA OA methods vs NNV2.0 

% function plot_reachable_sets()
%     %% Initialization
%     close all;
%     % Define specific colors: red, green, blue, magenta, cyan, yellow
%     colors = [1, 0, 0;    % Red
%               0, 1, 0;    % Green
%               0, 0, 1;    % Blue
%               1, 0, 1;    % Magenta
%               0, 1, 1;    % Cyan
%               1, 1, 0];   % Yellow
%     % Assign colors to combinations
%     color_map = containers.Map({'initial_CT Mixed-Monotonicity', 'incremental_CT Mixed-Monotonicity', ...
%                                'initial_CT Sampled-Data Mixed-Monotonicity', 'incremental_CT Sampled-Data Mixed-Monotonicity', ...
%                                'initial_NNV Star Set', 'incremental_NNV Star Set'}, ...
%                               mat2cell(colors, ones(1, 6)));
% 
%     method_names = {'CT Mixed-Monotonicity', 'CT Sampled-Data Mixed-Monotonicity', 'NNV Star Set'};
% 
%     %% Load data from multiple runs
%     files = dir('reachability_data_sys*.mat');
%     if isempty(files)
%         error('No reachability data files found. Run the main script first.');
%     end
% 
%     all_succ_low = {};
%     all_succ_up = {};
%     all_rand_succ = {};
%     all_t_points = {};
%     all_methods = {};
%     all_n_x = [];
%     all_n_methods = [];
% 
%     for i = 1:length(files)
%         data = load(files(i).name);
%         all_succ_low{end+1} = data.succ_low_all_methods;
%         all_succ_up{end+1} = data.succ_up_all_methods;
%         % Check for rand_succ or fall back to final_states
%         if isfield(data, 'rand_succ')
%             all_rand_succ{end+1} = data.rand_succ;
%         elseif isfield(data, 'final_states')
%             all_rand_succ{end+1} = data.final_states;
%         else
%             all_rand_succ{end+1} = zeros(size(data.succ_low_all_methods, 1), 0); % Default empty if neither exists
%         end
%         all_t_points{end+1} = data.t_points;
%         % Determine methods based on file type and approach
%         if isfield(data, 'methods')
%             all_methods{end+1} = data.methods; % Use TIRA methods
%         else
%             all_methods{end+1} = [5]; % Single method index 5 for NNV2.0
%         end
%         all_n_x(end+1) = data.n_x;
%         % Check for n_methods or use default 1 for NNV2.0 files
%         if isfield(data, 'n_methods')
%             all_n_methods(end+1) = data.n_methods;
%         else
%             all_n_methods(end+1) = 1; % Default for NNV2.0
%         end
%     end
% 
%     % Verify consistency
%     if length(unique(all_n_x)) > 1 || length(unique(all_n_methods)) > 1
%         warning('Inconsistent state or method dimensions across files. Using first file''s dimensions.');
%     end
%     n_x = all_n_x(1);
%     n_methods = all_n_methods(1);
% 
%     %% Plotting
%     if n_x == 5
%         plot_pairs = [1 2; 3 4; 4 5];
%         for i = 1:size(plot_pairs, 1)
%             figure;
%             hold on;
%             grid on;
%             idx1 = plot_pairs(i, 1);
%             idx2 = plot_pairs(i, 2);
% 
%             % Plot random successors from all runs
%             for j = 1:length(all_rand_succ)
%                 scatter(all_rand_succ{j}(idx1, :), all_rand_succ{j}(idx2, :), 5, 'k', 'filled');
%             end
% 
%             % Plot last reachable sets for each file
%             handles = [];
%             proxy_handles = [];
%             legends = {};
%             for j = 1:length(files)
%                 % Extract approach from filename
%                 approach_tokens = regexp(files(j).name, '_(initial|incremental)_', 'tokens');
%                 if isempty(approach_tokens)
%                     warning('No approach detected in file %s. Skipping.', files(j).name);
%                     continue;
%                 end
%                 approach = approach_tokens{1}{1};
%                 file_methods = all_methods{j}; % Methods from the current file
%                 % Check if this is an NNV2.0 file to handle both approaches
%                 is_nnv = contains(files(j).name, 'NNV');
%                 if is_nnv
%                     % Handle both initial and incremental approaches for NNV2.0
%                     for app = {'initial', 'incremental'}
%                         app_str = app{1};
%                         if strcmp(app_str, approach) || all(isnan(all_succ_low{j}(idx1, :, :))) % Plot if match or force for missing data
%                             for m = 1:length(method_names)
%                                 method_idx = find(file_methods == m + 2); % Look for method index
%                                 if ~isempty(method_idx)
%                                     k = length(all_t_points{j}); % Last time step
%                                     x_min = all_succ_low{j}(idx1, k, method_idx);
%                                     y_min = all_succ_low{j}(idx2, k, method_idx);
%                                     width = all_succ_up{j}(idx1, k, method_idx) - x_min;
%                                     height = all_succ_up{j}(idx2, k, method_idx) - y_min;
%                                     % Debug data shape and validity
%                                     if any(isnan([x_min, y_min, width, height]))
%                                         fprintf('Invalid data for file %s, approach %s, method %s at t=%d: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', ...
%                                                 files(j).name, app_str, method_names{m}, k, x_min, y_min, width, height);
%                                         fprintf('succ_low shape: %s, succ_up shape: %s\n', mat2str(size(all_succ_low{j})), mat2str(size(all_succ_up{j})));
%                                         if k > 1
%                                             k = k - 1; % Try previous time step
%                                             x_min = all_succ_low{j}(idx1, k, method_idx);
%                                             y_min = all_succ_low{j}(idx2, k, method_idx);
%                                             width = all_succ_up{j}(idx1, k, method_idx) - x_min;
%                                             height = all_succ_up{j}(idx2, k, method_idx) - y_min;
%                                             fprintf('Trying t=%d: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', k, x_min, y_min, width, height);
%                                         end
%                                     end
%                                     % Validate position values
%                                     if ~all(isfinite([x_min, y_min, width, height])) || any(isnan([x_min, y_min, width, height])) || width <= 0 || height <= 0
%                                         fprintf('Skipping invalid rectangle for file %s, approach %s, method %s: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', ...
%                                                 files(j).name, app_str, method_names{m}, x_min, y_min, width, height);
%                                         continue;
%                                     end
%                                     key = sprintf('%s_%s', app_str, method_names{m});
%                                     color = color_map(key);
%                                     line_width = 2; % Line width for all the boxes
%                                     if strcmp(key, 'incremental_CT Mixed-Monotonicity')
%                                         line_width = 4; % Special thicker line for green box
%                                     end
%                                     h = rectangle('Position', [x_min, y_min, width, height], ...
%                                                   'EdgeColor', color, 'LineWidth', line_width, 'LineStyle', '-');
%                                     handles = [handles, h];
%                                     h_proxy = plot(nan, nan, 'Color', color, 'LineWidth', line_width, 'LineStyle', '-', 'Visible', 'off');
%                                     proxy_handles = [proxy_handles, h_proxy];
%                                     legends{end+1} = sprintf('%s (%s)', method_names{m}, app_str);
%                                 end
%                             end
%                         end
%                     end
%                 else
%                     % Handle TIRA files with their methods
%                     for m = 1:length(method_names)
%                         method_value = find(file_methods == m + 2); % Adjust for method indices (3, 4, 5)
%                         if ~isempty(method_value)
%                             method_idx = method_value(1); % Take the first match
%                             k = length(all_t_points{j}); % Last time step
%                             x_min = all_succ_low{j}(idx1, k, method_idx);
%                             y_min = all_succ_low{j}(idx2, k, method_idx);
%                             width = all_succ_up{j}(idx1, k, method_idx) - x_min;
%                             height = all_succ_up{j}(idx2, k, method_idx) - y_min;
%                             % Validate position values
%                             if ~all(isfinite([x_min, y_min, width, height])) || any(isnan([x_min, y_min, width, height])) || width <= 0 || height <= 0
%                                 fprintf('Skipping invalid rectangle for file %s, approach %s, method %s: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', ...
%                                         files(j).name, approach, method_names{m}, x_min, y_min, width, height);
%                                 continue;
%                             end
%                             key = sprintf('%s_%s', approach, method_names{m});
%                             color = color_map(key);
%                             line_width = 2; % Line width for all the boxes
%                             if strcmp(key, 'incremental_CT Mixed-Monotonicity')
%                                 line_width = 8; % Special thicker line for green box
%                             end
%                             h = rectangle('Position', [x_min, y_min, width, height], ...
%                                           'EdgeColor', color, 'LineWidth', line_width, 'LineStyle', '-');
%                             handles = [handles, h];
%                             h_proxy = plot(nan, nan, 'Color', color, 'LineWidth', line_width, 'LineStyle', '-', 'Visible', 'off');
%                             proxy_handles = [proxy_handles, h_proxy];
%                             legends{end+1} = sprintf('%s (%s)', method_names{m}, approach);
%                         end
%                     end
%                 end
%             end
% 
%             % Add labels and legend only if there are valid handles
%             if ~isempty(proxy_handles) && length(proxy_handles) == length(legends)
%                 xlabel(['$x_', num2str(idx1), '$'], 'Interpreter', 'Latex', 'FontSize', 20);
%                 ylabel(['$x_', num2str(idx2), '$'], 'Interpreter', 'Latex', 'FontSize', 20);
%                 title(['$x_', num2str(idx1), '$ vs. $x_', num2str(idx2), '$'], 'Interpreter', 'Latex', 'FontSize', 16);
%                 legend(proxy_handles, legends, 'Location', 'southeast');
%             else
%                 warning('No valid rectangles or mismatched handles/legends for this plot. Skipping legend.');
%             end
%             hold off;
%         end
%     else
%         warning('Plotting is set up only for systems with 5 states.');
%     end
% end

%% For TIRA OA methods vs NNV2.0 vs CORA

% function plot_reachable_sets()
%     %% Initialization
%     close all;
%     % Define specific colors: red, green, blue, magenta, cyan, yellow
%     colors = [1, 0, 0;    % Red
%               0, 1, 0;    % Green
%               0, 0, 1;    % Blue
%               1, 0, 1;    % Magenta
%               0, 1, 1;    % Cyan
%               1, 1, 0];   % Yellow
%     % Assign colors to combinations
%     color_map = containers.Map({'single-step Mixed-Monotonicity', 'incremental Mixed-Monotonicity', ...
%                                'single-step Sampled-Data Mixed-Monotonicity', 'incremental Sampled-Data Mixed-Monotonicity', ...
%                                'NNV2.0 Star Set', 'CORA Zonotope'}, ...
%                               mat2cell(colors, ones(1, 6)));
% 
%     method_names = {'Mixed-Monotonicity', 'Sampled-Data Mixed-Monotonicity', 'NNV2.0 Star Set', 'CORA Zonotope'};
% 
%     %% Load data from multiple runs
%     files = dir('reachability_data_sys*.mat');
%     if isempty(files)
%         error('No reachability data files found. Run the main script first.');
%     end
% 
%     all_succ_low = {};
%     all_succ_up = {};
%     all_rand_succ = {};
%     all_t_points = {};
%     all_methods = {};
%     all_n_x = [];
%     all_n_methods = [];
% 
%     for i = 1:length(files)
%         data = load(files(i).name);
%         all_succ_low{end+1} = data.succ_low_all_methods;
%         all_succ_up{end+1} = data.succ_up_all_methods;
%         % Check for rand_succ or fall back to final_states
%         if isfield(data, 'rand_succ')
%             all_rand_succ{end+1} = data.rand_succ;
%         elseif isfield(data, 'final_states')
%             all_rand_succ{end+1} = data.final_states;
%         else
%             all_rand_succ{end+1} = zeros(size(data.succ_low_all_methods, 1), 0); % Default empty if neither exists
%         end
%         all_t_points{end+1} = data.t_points;
%         % Determine methods based on file type and approach
%         if isfield(data, 'methods')
%             all_methods{end+1} = data.methods; % Use TIRA methods
%         else
%             all_methods{end+1} = [5]; % Single method index 5 for NNV2.0
%         end
%         all_n_x(end+1) = data.n_x;
%         % Check for n_methods or use default 1 for NNV2.0 files
%         if isfield(data, 'n_methods')
%             all_n_methods(end+1) = data.n_methods;
%         else
%             all_n_methods(end+1) = 1; % Default for NNV2.0
%         end
%     end
% 
%     % Verify consistency
%     if length(unique(all_n_x)) > 1 || length(unique(all_n_methods)) > 1
%         warning('Inconsistent state or method dimensions across files. Using first file''s dimensions.');
%     end
%     n_x = all_n_x(1);
%     n_methods = all_n_methods(1);
% 
%     %% Plotting
%     if n_x == 5
%         plot_pairs = [1 2; 3 4; 4 5];
%         for i = 1:size(plot_pairs, 1)
%             figure;
%             hold on;
%             grid on;
%             idx1 = plot_pairs(i, 1);
%             idx2 = plot_pairs(i, 2);
% 
%             % Plot random successors from all runs
%             for j = 1:length(all_rand_succ)
%                 scatter(all_rand_succ{j}(idx1, :), all_rand_succ{j}(idx2, :), 5, 'k', 'filled');
%             end
% 
%             % Plot last reachable sets for each file
%             handles = [];
%             proxy_handles = [];
%             legends = {};
%             for j = 1:length(files)
%                 % Extract approach from filename
%                 approach_tokens = regexp(files(j).name, '_(initial|incremental)_', 'tokens');
%                 if isempty(approach_tokens)
%                     warning('No approach detected in file %s. Skipping.', files(j).name);
%                     continue;
%                 end
%                 approach = approach_tokens{1}{1};
%                 file_methods = all_methods{j}; % Methods from the current file
%                 % Check if this is an NNV2.0 file to handle both approaches
%                 is_nnv = contains(files(j).name, 'NNV');
%                 if is_nnv
%                     % Handle both initial and incremental approaches for NNV2.0
%                     for app = {'initial', 'incremental'}
%                         app_str = app{1};
%                         if strcmp(app_str, approach) || all(isnan(all_succ_low{j}(idx1, :, :))) % Plot if match or force for missing data
%                             for m = 1:length(method_names)
%                                 method_idx = find(file_methods == m + 2); % Look for method index
%                                 if ~isempty(method_idx)
%                                     k = length(all_t_points{j}); % Last time step
%                                     x_min = all_succ_low{j}(idx1, k, method_idx);
%                                     y_min = all_succ_low{j}(idx2, k, method_idx);
%                                     width = all_succ_up{j}(idx1, k, method_idx) - x_min;
%                                     height = all_succ_up{j}(idx2, k, method_idx) - y_min;
%                                     % Debug data shape and validity
%                                     if any(isnan([x_min, y_min, width, height]))
%                                         fprintf('Invalid data for file %s, approach %s, method %s at t=%d: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', ...
%                                                 files(j).name, app_str, method_names{m}, k, x_min, y_min, width, height);
%                                         fprintf('succ_low shape: %s, succ_up shape: %s\n', mat2str(size(all_succ_low{j})), mat2str(size(all_succ_up{j})));
%                                         if k > 1
%                                             k = k - 1; % Try previous time step
%                                             x_min = all_succ_low{j}(idx1, k, method_idx);
%                                             y_min = all_succ_low{j}(idx2, k, method_idx);
%                                             width = all_succ_up{j}(idx1, k, method_idx) - x_min;
%                                             height = all_succ_up{j}(idx2, k, method_idx) - y_min;
%                                             fprintf('Trying t=%d: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', k, x_min, y_min, width, height);
%                                         end
%                                     end
%                                     % Validate position values
%                                     if ~all(isfinite([x_min, y_min, width, height])) || any(isnan([x_min, y_min, width, height])) || width <= 0 || height <= 0
%                                         fprintf('Skipping invalid rectangle for file %s, approach %s, method %s: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', ...
%                                                 files(j).name, app_str, method_names{m}, x_min, y_min, width, height);
%                                         continue;
%                                     end
%                                     key = sprintf('%s_%s', app_str, method_names{m});
%                                     color = color_map(key);
%                                     line_width = 2; % Line width for all the boxes
%                                     if strcmp(key, 'incremental_CT Mixed-Monotonicity')
%                                         line_width = 4; % Special thicker line for green box
%                                     end
%                                     h = rectangle('Position', [x_min, y_min, width, height], ...
%                                                   'EdgeColor', color, 'LineWidth', line_width, 'LineStyle', '-');
%                                     handles = [handles, h];
%                                     h_proxy = plot(nan, nan, 'Color', color, 'LineWidth', line_width, 'LineStyle', '-', 'Visible', 'off');
%                                     proxy_handles = [proxy_handles, h_proxy];
%                                     legends{end+1} = sprintf('%s (%s)', method_names{m}, app_str);
%                                 end
%                             end
%                         end
%                     end
%                 else
%                     % Handle TIRA files with their methods
%                     for m = 1:length(method_names)
%                         method_value = find(file_methods == m + 2); % Adjust for method indices (3, 4, 5)
%                         if ~isempty(method_value)
%                             method_idx = method_value(1); % Take the first match
%                             k = length(all_t_points{j}); % Last time step
%                             x_min = all_succ_low{j}(idx1, k, method_idx);
%                             y_min = all_succ_low{j}(idx2, k, method_idx);
%                             width = all_succ_up{j}(idx1, k, method_idx) - x_min;
%                             height = all_succ_up{j}(idx2, k, method_idx) - y_min;
%                             % Validate position values
%                             if ~all(isfinite([x_min, y_min, width, height])) || any(isnan([x_min, y_min, width, height])) || width <= 0 || height <= 0
%                                 fprintf('Skipping invalid rectangle for file %s, approach %s, method %s: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', ...
%                                         files(j).name, approach, method_names{m}, x_min, y_min, width, height);
%                                 continue;
%                             end
%                             key = sprintf('%s_%s', approach, method_names{m});
%                             color = color_map(key);
%                             line_width = 2; % Line width for all the boxes
%                             if strcmp(key, 'incremental_CT Mixed-Monotonicity')
%                                 line_width = 8; % Special thicker line for green box
%                             end
%                             h = rectangle('Position', [x_min, y_min, width, height], ...
%                                           'EdgeColor', color, 'LineWidth', line_width, 'LineStyle', '-');
%                             handles = [handles, h];
%                             h_proxy = plot(nan, nan, 'Color', color, 'LineWidth', line_width, 'LineStyle', '-', 'Visible', 'off');
%                             proxy_handles = [proxy_handles, h_proxy];
%                             legends{end+1} = sprintf('%s (%s)', method_names{m}, approach);
%                         end
%                     end
%                 end
%             end
% 
%             % Add labels and legend only if there are valid handles
%             if ~isempty(proxy_handles) && length(proxy_handles) == length(legends)
%                 xlabel(['$x_', num2str(idx1), '$'], 'Interpreter', 'Latex', 'FontSize', 20);
%                 ylabel(['$x_', num2str(idx2), '$'], 'Interpreter', 'Latex', 'FontSize', 20);
%                 title(['$x_', num2str(idx1), '$ vs. $x_', num2str(idx2), '$'], 'Interpreter', 'Latex', 'FontSize', 16);
%                 legend(proxy_handles, legends, 'Location', 'southeast');
%             else
%                 warning('No valid rectangles or mismatched handles/legends for this plot. Skipping legend.');
%             end
%             hold off;
%         end
%     else
%         warning('Plotting is set up only for systems with 5 states.');
%     end
% end

% function plot_reachable_sets()
%     %% Initialization
%     close all;
%     % Define specific colors: red, green, blue, magenta, cyan, yellow
%     colors = [1, 0, 0;    % Red
%               0, 1, 0;    % Green
%               0, 0, 1;    % Blue
%               1, 0, 1;    % Magenta
%               0, 1, 1;    % Cyan
%               1, 1, 0];   % Yellow
%     % Assign colors to combinations
%     color_map = containers.Map({'single-step Mixed-Monotonicity', 'incremental Mixed-Monotonicity', ...
%                                'single-step Sampled-Data Mixed-Monotonicity', 'incremental Sampled-Data Mixed-Monotonicity', ...
%                                'NNV2.0 Star Set', 'CORA Zonotope'}, ...
%                               mat2cell(colors, ones(1, 6)));
% 
%     method_names = {'Mixed-Monotonicity', 'Sampled-Data Mixed-Monotonicity', 'NNV2.0 Star Set', 'CORA Zonotope'};
% 
%     %% Load data from multiple runs
%     files = dir('reachability_data_sys*.mat');
%     if isempty(files)
%         error('No reachability data files found. Run the main script first.');
%     end
% 
%     all_succ_low = {};
%     all_succ_up = {};
%     all_rand_succ = {};
%     all_t_points = {};
%     all_methods = {};
%     all_n_x = [];
%     all_n_methods = [];
% 
%     for i = 1:length(files)
%         data = load(files(i).name);
%         if isfield(data, 'succ_low_all_methods') && isfield(data, 'succ_up_all_methods')
%             % TIRA data
%             all_succ_low{end+1} = data.succ_low_all_methods;
%             all_succ_up{end+1} = data.succ_up_all_methods;
%             all_t_points{end+1} = data.t_points;
%             all_methods{end+1} = data.methods;
%             all_n_methods(end+1) = data.n_methods;
%         elseif isfield(data, 'final_reachable_set')
%             % CORA data
%             final_interval = interval(data.final_reachable_set);
%             succ_low = final_interval.inf;
%             succ_up = final_interval.sup;
%             all_succ_low{end+1} = reshape(succ_low, [size(succ_low, 1), 1, 1]); % Reshape for consistency
%             all_succ_up{end+1} = reshape(succ_up, [size(succ_up, 1), 1, 1]);
%             all_t_points{end+1} = data.tFinal; % Single time point
%             all_methods{end+1} = [5]; % Method index 5 for CORA Zonotope
%             all_n_methods(end+1) = 1;
%         else
%             % NNV2.0 or other data
%             all_succ_low{end+1} = nan(data.n_x, 1, 1); % Placeholder
%             all_succ_up{end+1} = nan(data.n_x, 1, 1);
%             all_t_points{end+1} = data.t_points;
%             all_methods{end+1} = [5]; % Method index 5 for NNV2.0
%             all_n_methods(end+1) = 1;
%         end
%         % Handle random successors
%         if isfield(data, 'rand_succ')
%             all_rand_succ{end+1} = data.rand_succ;
%         elseif isfield(data, 'final_states')
%             all_rand_succ{end+1} = data.final_states;
%         else
%             all_rand_succ{end+1} = zeros(data.n_x, 0); % Empty if none
%         end
%         all_n_x(end+1) = data.n_x;
%     end
% 
%     % Verify consistency
%     if length(unique(all_n_x)) > 1 || length(unique(all_n_methods)) > 1
%         warning('Inconsistent state or method dimensions across files. Using first file''s dimensions.');
%     end
%     n_x = all_n_x(1);
%     n_methods = max(all_n_methods);
% 
%     %% Plotting
%     if n_x == 5
%         plot_pairs = [1 2; 3 4; 4 5];
%         for i = 1:size(plot_pairs, 1)
%             figure;
%             hold on;
%             grid on;
%             idx1 = plot_pairs(i, 1);
%             idx2 = plot_pairs(i, 2);
% 
%             % Plot random successors from all runs
%             for j = 1:length(all_rand_succ)
%                 scatter(all_rand_succ{j}(idx1, :), all_rand_succ{j}(idx2, :), 5, 'k', 'filled');
%             end
% 
%             % Plot last reachable sets for each file
%             handles = [];
%             proxy_handles = [];
%             legends = [];
%             for j = 1:length(files)
%                 % Extract approach from filename
%                 approach_tokens = regexp(files(j).name, '_(single-step|incremental)_', 'tokens');
%                 if isempty(approach_tokens)
%                     if contains(files(j).name, 'NNV')
%                         approach = 'NNV2.0';
%                     elseif contains(files(j).name, 'CORA')
%                         approach = 'CORA';
%                     else
%                         warning('No approach detected in file %s. Skipping.', files(j).name);
%                         continue;
%                     end
%                 else
%                     approach = approach_tokens{1}{1};
%                 end
%                 file_methods = all_methods{j};
%                 for m = 1:length(method_names)
%                     method_idx = find(file_methods == m + 2); % Adjust for method indices (3, 4, 5)
%                     if ~isempty(method_idx)
%                         method_idx = method_idx(1); % Take first match
%                         k = size(all_succ_low{j}, 2); % Last time step
%                         x_min = all_succ_low{j}(idx1, k, method_idx);
%                         y_min = all_succ_low{j}(idx2, k, method_idx);
%                         width = all_succ_up{j}(idx1, k, method_idx) - x_min;
%                         height = all_succ_up{j}(idx2, k, method_idx) - y_min;
%                         % Validate position values
%                         if ~all(isfinite([x_min, y_min, width, height])) || any(isnan([x_min, y_min, width, height])) || width <= 0 || height <= 0
%                             fprintf('Skipping invalid rectangle for file %s, approach %s, method %s: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', ...
%                                     files(j).name, approach, method_names{m}, x_min, y_min, width, height);
%                             continue;
%                         end
%                         key = method_names{m};
%                         if strcmp(approach, 'single-step') || strcmp(approach, 'incremental')
%                             key = sprintf('%s_%s', approach, method_names{m});
%                         end
%                         if ~isKey(color_map, key)
%                             key = method_names{m}; % Fallback for NNV2.0 or CORA
%                         end
%                         color = color_map(key);
%                         line_width = 2;
%                         if strcmp(key, 'incremental_Mixed-Monotonicity')
%                             line_width = 4;
%                         end
%                         h = rectangle('Position', [x_min, y_min, width, height], ...
%                                       'EdgeColor', color, 'LineWidth', line_width, 'LineStyle', '-');
%                         handles = [handles, h];
%                         h_proxy = plot(nan, nan, 'Color', color, 'LineWidth', line_width, 'LineStyle', '-', 'Visible', 'off');
%                         proxy_handles = [proxy_handles, h_proxy];
%                         legends{end+1} = sprintf('%s (%s)', method_names{m}, approach);
%                     end
%                 end
%             end
% 
%             % Add labels and legend
%             if ~isempty(proxy_handles) && length(proxy_handles) == length(legends)
%                 xlabel(['$x_', num2str(idx1), '$'], 'Interpreter', 'Latex', 'FontSize', 20);
%                 ylabel(['$x_', num2str(idx2), '$'], 'Interpreter', 'Latex', 'FontSize', 20);
%                 title(['$x_', num2str(idx1), '$ vs. $x_', num2str(idx2), '$'], 'Interpreter', 'Latex', 'FontSize', 16);
%                 legend(proxy_handles, legends, 'Location', 'southeast');
%             else
%                 warning('No valid rectangles or mismatched handles/legends for plot %d.', i);
%             end
%             hold off;
%         end
%     else
%         warning('Plotting is set up only for systems with 5 states.');
%     end
% end

% function plot_reachable_sets()
%     %% Initialization
%     close all;
%     % Define specific colors: red, green, blue, magenta, cyan, yellow
%     colors = [1, 0, 0;    % Red
%               0, 1, 0;    % Green
%               0, 0, 1;    % Blue
%               1, 0, 1;    % Magenta
%               0, 1, 1;    % Cyan
%               1, 1, 0];   % Yellow
%     % Assign colors to combinations
%     color_map = containers.Map({'single-step_Mixed-Monotonicity', 'incremental_Mixed-Monotonicity', ...
%                                'single-step_Sampled-Data Mixed-Monotonicity', 'incremental_Sampled-Data Mixed-Monotonicity', ...
%                                'NNV2.0 Star Set', 'CORA Zonotope'}, ...
%                               mat2cell(colors, ones(1, 6)));
% 
%     method_names = {'Mixed-Monotonicity', 'Sampled-Data Mixed-Monotonicity', 'NNV2.0 Star Set', 'CORA Zonotope'};
% 
%     %% Load data from multiple runs
%     files = dir('reachability_data_sys*.mat');
%     if isempty(files)
%         error('No reachability data files found. Run the main script first.');
%     end
% 
%     all_succ_low = {};
%     all_succ_up = {};
%     all_rand_succ = {};
%     all_t_points = {};
%     all_methods = {};
%     all_n_x = [];
%     all_n_methods = [];
% 
%     for i = 1:length(files)
%         data = load(files(i).name);
%         % Check file type
%         is_tira = isfield(data, 'succ_low_all_methods') && isfield(data, 'succ_up_all_methods') && isfield(data, 'methods');
%         is_cora = isfield(data, 'final_reachable_set');
%         is_nnv = contains(files(i).name, 'NNV') && ~is_tira && ~is_cora;
% 
%         if is_tira
%             % TIRA data
%             all_succ_low{end+1} = data.succ_low_all_methods;
%             all_succ_up{end+1} = data.succ_up_all_methods;
%             all_t_points{end+1} = data.t_points;
%             all_methods{end+1} = data.methods;
%             all_n_methods(end+1) = data.n_methods;
%             all_n_x(end+1) = data.n_x;
%         elseif is_cora
%             % CORA data
%             final_interval = interval(data.final_reachable_set);
%             succ_low = final_interval.inf;
%             succ_up = final_interval.sup;
%             all_succ_low{end+1} = reshape(succ_low, [size(succ_low, 1), 1, 1]); % [n_x, steps, n_methods]
%             all_succ_up{end+1} = reshape(succ_up, [size(succ_up, 1), 1, 1]);
%             all_t_points{end+1} = data.t_points;
%             all_methods{end+1} = data.methods; % Should be [6] for CORA Zonotope
%             all_n_methods(end+1) = data.n_methods; % Should be 1
%             all_n_x(end+1) = data.n_x;
%         elseif is_nnv
%             % NNV2.0 data (assuming similar structure to CORA or TIRA)
%             if isfield(data, 'final_reachable_set')
%                 % NNV2.0 with final_reachable_set (similar to CORA)
%                 final_interval = interval(data.final_reachable_set);
%                 succ_low = final_interval.inf;
%                 succ_up = final_interval.sup;
%                 all_succ_low{end+1} = reshape(succ_low, [size(succ_low, 1), 1, 1]);
%                 all_succ_up{end+1} = reshape(succ_up, [size(succ_up, 1), 1, 1]);
%                 all_t_points{end+1} = data.tFinal; % Use tFinal if t_points unavailable
%                 all_methods{end+1} = [5]; % Method index 5 for NNV2.0
%                 all_n_methods(end+1) = 1;
%                 all_n_x(end+1) = data.n_x;
%             elseif isfield(data, 'succ_low_all_methods') && isfield(data, 'succ_up_all_methods')
%                 % NNV2.0 with TIRA-like structure
%                 all_succ_low{end+1} = data.succ_low_all_methods;
%                 all_succ_up{end+1} = data.succ_up_all_methods;
%                 all_t_points{end+1} = data.t_points;
%                 all_methods{end+1} = [5]; % Method index 5 for NNV2.0
%                 all_n_methods(end+1) = data.n_methods;
%                 all_n_x(end+1) = data.n_x;
%             else
%                 % Fallback for unrecognized NNV2.0 structure
%                 warning('Unrecognized NNV2.0 file structure for %s. Skipping.', files(i).name);
%                 all_succ_low{end+1} = nan(data.n_x, 1, 1);
%                 all_succ_up{end+1} = nan(data.n_x, 1, 1);
%                 all_t_points{end+1} = 0;
%                 all_methods{end+1} = [5];
%                 all_n_methods(end+1) = 1;
%                 all_n_x(end+1) = data.n_x;
%             end
%         else
%             % Unrecognized file type
%             warning('Unrecognized file structure for %s. Skipping.', files(i).name);
%             all_succ_low{end+1} = nan(data.n_x, 1, 1);
%             all_succ_up{end+1} = nan(data.n_x, 1, 1);
%             all_t_points{end+1} = 0;
%             all_methods{end+1} = [5];
%             all_n_methods(end+1) = 1;
%             all_n_x(end+1) = data.n_x;
%         end
%         % Handle random successors
%         if isfield(data, 'rand_succ')
%             all_rand_succ{end+1} = data.rand_succ;
%         elseif isfield(data, 'final_states')
%             all_rand_succ{end+1} = data.final_states;
%         else
%             all_rand_succ{end+1} = zeros(data.n_x, 0);
%         end
%     end
% 
%     % Verify consistency
%     if length(unique(all_n_x)) > 1
%         warning('Inconsistent state dimensions across files. Using first file''s dimensions.');
%     end
%     n_x = all_n_x(1);
%     n_methods = max(all_n_methods);
% 
%     %% Plotting
%     if n_x == 5
%         plot_pairs = [1 2; 3 4; 4 5];
%         for i = 1:size(plot_pairs, 1)
%             figure;
%             hold on;
%             grid on;
%             idx1 = plot_pairs(i, 1);
%             idx2 = plot_pairs(i, 2);
% 
%             % Plot random successors from all runs
%             for j = 1:length(all_rand_succ)
%                 if ~isempty(all_rand_succ{j})
%                     scatter(all_rand_succ{j}(idx1, :), all_rand_succ{j}(idx2, :), 5, 'k', 'filled');
%                 end
%             end
% 
%             % Plot last reachable sets for each file
%             handles = [];
%             proxy_handles = [];
%             legends = {};
%             for j = 1:length(files)
%                 % Extract approach from filename
%                 approach_tokens = regexp(files(j).name, '_(single-step|incremental|CORA|NNV)_', 'tokens');
%                 if isempty(approach_tokens)
%                     warning('No approach detected in file %s. Assuming generic.', files(j).name);
%                     approach = 'Unknown';
%                 else
%                     approach = approach_tokens{1}{1};
%                 end
%                 file_methods = all_methods{j};
%                 % Determine which methods to plot based on approach
%                 method_indices = 1:length(method_names);
%                 if strcmp(approach, 'CORA')
%                     method_indices = 4; % CORA Zonotope
%                 elseif strcmp(approach, 'NNV')
%                     method_indices = 3; % NNV2.0 Star Set
%                 end
%                 for m = method_indices
%                     expected_method_idx = m + 2; % 3, 4 for TIRA; 5 for NNV; 6 for CORA
%                     method_idx = find(file_methods == expected_method_idx);
%                     if ~isempty(method_idx)
%                         method_idx = method_idx(1);
%                         k = size(all_succ_low{j}, 2); % Last time step
%                         x_min = all_succ_low{j}(idx1, k, method_idx);
%                         y_min = all_succ_low{j}(idx2, k, method_idx);
%                         width = all_succ_up{j}(idx1, k, method_idx) - x_min;
%                         height = all_succ_up{j}(idx2, k, method_idx) - y_min;
%                         % Validate position values
%                         if ~all(isfinite([x_min, y_min, width, height])) || any(isnan([x_min, y_min, width, height])) || width <= 0 || height <= 0
%                             fprintf('Skipping invalid rectangle for file %s, approach %s, method %s: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', ...
%                                     files(j).name, approach, method_names{m}, x_min, y_min, width, height);
%                             continue;
%                         end
%                         key = method_names{m};
%                         if strcmp(approach, 'single-step') || strcmp(approach, 'incremental')
%                             key = sprintf('%s_%s', approach, method_names{m});
%                         elseif strcmp(approach, 'CORA')
%                             key = 'CORA Zonotope';
%                         elseif strcmp(approach, 'NNV')
%                             key = 'NNV2.0 Star Set';
%                         end
%                         color = color_map(key);
%                         line_width = 2;
%                         if strcmp(key, 'incremental_Mixed-Monotonicity')
%                             line_width = 4;
%                         end
%                         h = rectangle('Position', [x_min, y_min, width, height], ...
%                                       'EdgeColor', color, 'LineWidth', line_width, 'LineStyle', '-');
%                         handles = [handles, h];
%                         h_proxy = plot(nan, nan, 'Color', color, 'LineWidth', line_width, 'LineStyle', '-', 'Visible', 'off');
%                         proxy_handles = [proxy_handles, h_proxy];
%                         legends{end+1} = sprintf('%s (%s)', method_names{m}, approach);
%                     end
%                 end
%             end
% 
%             % Add labels and legend
%             if ~isempty(proxy_handles) && length(proxy_handles) == length(legends)
%                 xlabel(['$x_', num2str(idx1), '$'], 'Interpreter', 'Latex', 'FontSize', 20);
%                 ylabel(['$x_', num2str(idx2), '$'], 'Interpreter', 'Latex', 'FontSize', 20);
%                 title(['$x_', num2str(idx1), '$ vs. $x_', num2str(idx2), '$'], 'Interpreter', 'Latex', 'FontSize', 16);
%                 legend(proxy_handles, legends, 'Location', 'southeast');
%             else
%                 warning('No valid rectangles or mismatched handles/legends for plot %d.', i);
%             end
%             hold off;
%         end
%     else
%         warning('Plotting is set up only for systems with 5 states.');
%     end
% end

%% Working for all 3 Toolboxes

% function plot_reachable_sets()
%     %% Initialization
%     close all;
%     % Define specific colors: red, green, blue, magenta, cyan, yellow, purple
%     colors = [1, 0, 0;    % Red
%               0, 1, 0;    % Green
%               0, 0, 1;    % Blue
%               1, 0, 1;    % Magenta
%               0, 1, 1;    % Cyan
%               1, 1, 0;    % Yellow
%               0.5, 0, 0.5]; % Purple
%     % Assign colors to combinations
%     color_map = containers.Map({'single-step Mixed-Monotonicity', 'incremental Mixed-Monotonicity', ...
%                                'single-step Sampled-Data Mixed-Monotonicity', 'incremental Sampled-Data Mixed-Monotonicity', ...
%                                'NNV2.0 Star Set', 'incremental NNV Star Set', 'CORA Zonotope'}, ...
%                               mat2cell(colors, ones(1, 7)));
% 
%     method_names = {'Mixed-Monotonicity', 'Sampled-Data Mixed-Monotonicity', 'NNV Star Set', 'CORA Zonotope'};
% 
%     %% Load data from multiple runs
%     files = dir('reachability_data_sys*.mat');
%     if isempty(files)
%         error('No reachability data files found. Run the main script first.');
%     end
% 
%     all_succ_low = {};
%     all_succ_up = {};
%     all_rand_succ = {};
%     all_t_points = {};
%     all_methods = {};
%     all_n_x = [];
%     all_n_methods = [];
% 
%     for i = 1:length(files)
%         data = load(files(i).name);
%         % Check file type
%         is_tira = isfield(data, 'succ_low_all_methods') && isfield(data, 'succ_up_all_methods') && isfield(data, 'methods');
%         is_nnv = contains(files(i).name, 'NNV');
%         is_cora = contains(files(i).name, 'CORA') || isfield(data, 'final_reachable_set');
% 
%         if is_tira
%             % TIRA data
%             all_succ_low{end+1} = data.succ_low_all_methods;
%             all_succ_up{end+1} = data.succ_up_all_methods;
%             all_t_points{end+1} = data.t_points;
%             all_methods{end+1} = data.methods;
%             all_n_methods(end+1) = data.n_methods;
%             all_n_x(end+1) = data.n_x;
%         elseif is_nnv
%             % NNV data (assuming structure similar to TIRA or with final_states)
%             if isfield(data, 'succ_low_all_methods') && isfield(data, 'succ_up_all_methods')
%                 all_succ_low{end+1} = data.succ_low_all_methods;
%                 all_succ_up{end+1} = data.succ_up_all_methods;
%             else
%                 all_succ_low{end+1} = nan(data.n_x, 1, 1); % Placeholder if missing
%                 all_succ_up{end+1} = nan(data.n_x, 1, 1);
%             end
%             all_t_points{end+1} = data.t_points;
%             all_methods{end+1} = [5]; % Method index 5 for NNV
%             all_n_methods(end+1) = 1;
%             all_n_x(end+1) = data.n_x;
%         elseif is_cora
%             % CORA data
%             if isfield(data, 'succ_low_all_methods') && isfield(data, 'succ_up_all_methods')
%                 all_succ_low{end+1} = data.succ_low_all_methods;
%                 all_succ_up{end+1} = data.succ_up_all_methods;
%             elseif isfield(data, 'final_reachable_set')
%                 final_interval = interval(data.final_reachable_set);
%                 succ_low = final_interval.inf;
%                 succ_up = final_interval.sup;
%                 all_succ_low{end+1} = reshape(succ_low, [size(succ_low, 1), 1, 1]); % Reshape for consistency
%                 all_succ_up{end+1} = reshape(succ_up, [size(succ_up, 1), 1, 1]);
%             else
%                 all_succ_low{end+1} = nan(data.n_x, 1, 1); % Placeholder if missing
%                 all_succ_up{end+1} = nan(data.n_x, 1, 1);
%             end
%             if isfield(data, 't_points')
%                 all_t_points{end+1} = data.t_points;
%             else
%                 all_t_points{end+1} = [data.tFinal]; % Use tFinal if t_points unavailable
%             end
%             if isfield(data, 'methods')
%                 all_methods{end+1} = data.methods; % Use if present (e.g., [6] for CORA)
%             else
%                 all_methods{end+1} = [6]; % Method index 6 for CORA
%             end
%             if isfield(data, 'n_methods')
%                 all_n_methods(end+1) = data.n_methods;
%             else
%                 all_n_methods(end+1) = 1;
%             end
%             if isfield(data, 'n_x')
%                 all_n_x(end+1) = data.n_x;
%             elseif isfield(data, 'dim')
%                 all_n_x(end+1) = data.dim;
%             else
%                 all_n_x(end+1) = 5; % Default assumption
%             end
%         else
%             warning('Unrecognized file type for %s. Skipping.', files(i).name);
%             continue;
%         end
%         % Handle random successors
%         if isfield(data, 'rand_succ')
%             all_rand_succ{end+1} = data.rand_succ;
%         elseif isfield(data, 'final_states')
%             all_rand_succ{end+1} = data.final_states;
%         elseif isfield(data, 'final_states_sampled')
%             all_rand_succ{end+1} = data.final_states_sampled;
%         else
%             all_rand_succ{end+1} = zeros(all_n_x(end), 0); % Default empty
%         end
%     end
% 
%     % Verify consistency
%     if length(unique(all_n_x)) > 1 || length(unique(all_n_methods)) > 1
%         warning('Inconsistent state or method dimensions across files. Using first file''s dimensions.');
%     end
%     n_x = all_n_x(1);
%     n_methods = max(all_n_methods);
% 
%     %% Plotting
%     if n_x == 5
%         plot_pairs = [1 2; 3 4; 4 5];
%         for i = 1:size(plot_pairs, 1)
%             figure;
%             hold on;
%             grid on;
%             idx1 = plot_pairs(i, 1);
%             idx2 = plot_pairs(i, 2);
% 
%             % Plot random successors from all runs
%             for j = 1:length(all_rand_succ)
%                 scatter(all_rand_succ{j}(idx1, :), all_rand_succ{j}(idx2, :), 5, 'k', 'filled');
%             end
% 
%             % Plot last reachable sets for each file
%             handles = [];
%             proxy_handles = [];
%             legends = {};
%             for j = 1:length(files)
%                 % Extract approach from filename
%                 approach_tokens = regexp(files(j).name, '_(initial|incremental)_', 'tokens');
%                 if isempty(approach_tokens)
%                     if contains(files(j).name, 'CORA')
%                         approach = 'CORA';
%                     else
%                         warning('No approach detected in file %s. Skipping.', files(j).name);
%                         continue;
%                     end
%                 else
%                     approach = approach_tokens{1}{1};
%                 end
%                 file_methods = all_methods{j}; % Methods from the current file
%                 % Check file type
%                 is_nnv = contains(files(j).name, 'NNV');
%                 is_cora = strcmp(approach, 'CORA');
%                 if is_nnv
%                     % Handle both initial and incremental approaches for NNV
%                     for app = {'initial', 'incremental'}
%                         app_str = app{1};
%                         if strcmp(app_str, approach) || all(isnan(all_succ_low{j}(idx1, :, :))) % Plot if match or force for missing data
%                             for m = 3:3 % NNV is method 3
%                                 method_idx = find(file_methods == m + 2); % 5 for NNV
%                                 if ~isempty(method_idx)
%                                     k = length(all_t_points{j}); % Last time step
%                                     x_min = all_succ_low{j}(idx1, k, method_idx);
%                                     y_min = all_succ_low{j}(idx2, k, method_idx);
%                                     width = all_succ_up{j}(idx1, k, method_idx) - x_min;
%                                     height = all_succ_up{j}(idx2, k, method_idx) - y_min;
%                                     % Debug data shape and validity
%                                     if any(isnan([x_min, y_min, width, height]))
%                                         fprintf('Invalid data for file %s, approach %s, method %s at t=%d: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', ...
%                                                 files(j).name, app_str, method_names{m}, k, x_min, y_min, width, height);
%                                         fprintf('succ_low shape: %s, succ_up shape: %s\n', mat2str(size(all_succ_low{j})), mat2str(size(all_succ_up{j})));
%                                         if k > 1
%                                             k = k - 1; % Try previous time step
%                                             x_min = all_succ_low{j}(idx1, k, method_idx);
%                                             y_min = all_succ_low{j}(idx2, k, method_idx);
%                                             width = all_succ_up{j}(idx1, k, method_idx) - x_min;
%                                             height = all_succ_up{j}(idx2, k, method_idx) - y_min;
%                                             fprintf('Trying t=%d: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', k, x_min, y_min, width, height);
%                                         end
%                                     end
%                                     % Validate position values
%                                     if ~all(isfinite([x_min, y_min, width, height])) || any(isnan([x_min, y_min, width, height])) || width <= 0 || height <= 0
%                                         fprintf('Skipping invalid rectangle for file %s, approach %s, method %s: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', ...
%                                                 files(j).name, app_str, method_names{m}, x_min, y_min, width, height);
%                                         continue;
%                                     end
%                                     if strcmp(app_str, 'initial')
%                                         key = 'NNV2.0 Star Set';
%                                         legend_str = 'NNV2.0 Star Set (single-step)';
%                                     else
%                                         key = sprintf('%s %s', app_str, 'NNV Star Set');
%                                         legend_str = sprintf('%s (%s)', method_names{m}, app_str);
%                                     end
%                                     color = color_map(key);
%                                     line_width = 2; % Line width for all the boxes
%                                     h = rectangle('Position', [x_min, y_min, width, height], ...
%                                                   'EdgeColor', color, 'LineWidth', line_width, 'LineStyle', '-');
%                                     handles = [handles, h];
%                                     h_proxy = plot(nan, nan, 'Color', color, 'LineWidth', line_width, 'LineStyle', '-', 'Visible', 'off');
%                                     proxy_handles = [proxy_handles, h_proxy];
%                                     legends{end+1} = legend_str;
%                                 end
%                             end
%                         end
%                     end
%                 elseif is_cora
%                     % Handle CORA (no initial/incremental, just CORA)
%                     for m = 4:4 % CORA is method 4
%                         method_idx = find(file_methods == m + 2); % 6 for CORA
%                         if ~isempty(method_idx)
%                             k = length(all_t_points{j}); % Last time step
%                             x_min = all_succ_low{j}(idx1, k, method_idx);
%                             y_min = all_succ_low{j}(idx2, k, method_idx);
%                             width = all_succ_up{j}(idx1, k, method_idx) - x_min;
%                             height = all_succ_up{j}(idx2, k, method_idx) - y_min;
%                             % Debug data shape and validity
%                             if any(isnan([x_min, y_min, width, height]))
%                                 fprintf('Invalid data for file %s, approach %s, method %s at t=%d: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', ...
%                                         files(j).name, approach, method_names{m}, k, x_min, y_min, width, height);
%                                         fprintf('succ_low shape: %s, succ_up shape: %s\n', mat2str(size(all_succ_low{j})), mat2str(size(all_succ_up{j})));
%                                         if k > 1
%                                             k = k - 1; % Try previous time step
%                                             x_min = all_succ_low{j}(idx1, k, method_idx);
%                                             y_min = all_succ_low{j}(idx2, k, method_idx);
%                                             width = all_succ_up{j}(idx1, k, method_idx) - x_min;
%                                             height = all_succ_up{j}(idx2, k, method_idx) - y_min;
%                                             fprintf('Trying t=%d: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', k, x_min, y_min, width, height);
%                                         end
%                             end
%                             % Validate position values
%                             if ~all(isfinite([x_min, y_min, width, height])) || any(isnan([x_min, y_min, width, height])) || width <= 0 || height <= 0
%                                 fprintf('Skipping invalid rectangle for file %s, approach %s, method %s: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', ...
%                                         files(j).name, approach, method_names{m}, x_min, y_min, width, height);
%                                 continue;
%                             end
%                             key = 'CORA Zonotope';
%                             color = color_map(key);
%                             line_width = 2; % Line width for all the boxes
%                             h = rectangle('Position', [x_min, y_min, width, height], ...
%                                           'EdgeColor', color, 'LineWidth', line_width, 'LineStyle', '-');
%                             handles = [handles, h];
%                             h_proxy = plot(nan, nan, 'Color', color, 'LineWidth', line_width, 'LineStyle', '-', 'Visible', 'off');
%                             proxy_handles = [proxy_handles, h_proxy];
%                             legends{end+1} = method_names{m};
%                         end
%                     end
%                 else
%                     % Handle TIRA files with their methods
%                     for m = 1:2 % TIRA methods 1 and 2
%                         method_value = find(file_methods == m + 2); % 3 and 4 for TIRA
%                         if ~isempty(method_value)
%                             method_idx = method_value(1); % Take the first match
%                             k = length(all_t_points{j}); % Last time step
%                             x_min = all_succ_low{j}(idx1, k, method_idx);
%                             y_min = all_succ_low{j}(idx2, k, method_idx);
%                             width = all_succ_up{j}(idx1, k, method_idx) - x_min;
%                             height = all_succ_up{j}(idx2, k, method_idx) - y_min;
%                             % Validate position values
%                             if ~all(isfinite([x_min, y_min, width, height])) || any(isnan([x_min, y_min, width, height])) || width <= 0 || height <= 0
%                                 fprintf('Skipping invalid rectangle for file %s, approach %s, method %s: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', ...
%                                         files(j).name, approach, method_names{m}, x_min, y_min, width, height);
%                                 continue;
%                             end
%                             if strcmp(approach, 'initial')
%                                 if m == 1
%                                     key = 'single-step Mixed-Monotonicity';
%                                 elseif m == 2
%                                     key = 'single-step Sampled-Data Mixed-Monotonicity';
%                                 end
%                                 legend_str = sprintf('%s (single-step)', method_names{m});
%                             else
%                                 key = sprintf('%s %s', approach, method_names{m});
%                                 legend_str = sprintf('%s (%s)', method_names{m}, approach);
%                             end
%                             color = color_map(key);
%                             line_width = 2; % Line width for all the boxes
%                             if strcmp(key, 'incremental Mixed-Monotonicity')
%                                 line_width = 8; % Special thicker line for green box
%                             end
%                             h = rectangle('Position', [x_min, y_min, width, height], ...
%                                           'EdgeColor', color, 'LineWidth', line_width, 'LineStyle', '-');
%                             handles = [handles, h];
%                             h_proxy = plot(nan, nan, 'Color', color, 'LineWidth', line_width, 'LineStyle', '-', 'Visible', 'off');
%                             proxy_handles = [proxy_handles, h_proxy];
%                             legends{end+1} = legend_str;
%                         end
%                     end
%                 end
%             end
% 
%             % Add labels and legend only if there are valid handles
%             if ~isempty(proxy_handles) && length(proxy_handles) == length(legends)
%                 xlabel(['$x_', num2str(idx1), '$'], 'Interpreter', 'Latex', 'FontSize', 20);
%                 ylabel(['$x_', num2str(idx2), '$'], 'Interpreter', 'Latex', 'FontSize', 20);
%                 title(['$x_', num2str(idx1), '$ vs. $x_', num2str(idx2), '$'], 'Interpreter', 'Latex', 'FontSize', 16);
%                 legend(proxy_handles, legends, 'Location', 'southeast');
%             else
%                 warning('No valid rectangles or mismatched handles/legends for this plot. Skipping legend.');
%             end
%             hold off;
%         end
%     else
%         warning('Plotting is set up only for systems with 5 states.');
%     end
% end

function plot_reachable_sets()
    %% Initialization
    close all;
    % Define specific colors: red, green, blue, magenta, cyan, yellow, purple
    colors = [1, 0, 0;    % Red
              0, 1, 0;    % Green
              0, 0, 1;    % Blue
              1, 0, 1;    % Magenta
              0, 1, 1;    % Cyan
              1, 1, 0;    % Yellow
              0.5, 0, 0.5]; % Purple
    % Assign colors to combinations
    color_map = containers.Map({'single-step Mixed-Monotonicity', 'incremental Mixed-Monotonicity', ...
                               'single-step Sampled-Data Mixed-Monotonicity', 'incremental Sampled-Data Mixed-Monotonicity', ...
                               'NNV2.0 Star Set', 'incremental NNV Star Set', 'CORA Zonotope'}, ...
                              mat2cell(colors, ones(1, 7)));

    method_names = {'Mixed-Monotonicity', 'Sampled-Data Mixed-Monotonicity', 'NNV Star Set', 'CORA Zonotope'};

    %% Load data from multiple runs
    files = dir('reachability_data_sys*.mat');
    if isempty(files)
        error('No reachability data files found. Run the main script first.');
    end

    all_succ_low = {};
    all_succ_up = {};
    all_rand_succ = {};
    all_t_points = {};
    all_methods = {};
    all_n_x = [];
    all_n_methods = [];
    all_final_sets = {};

    for i = 1:length(files)
        data = load(files(i).name);
        % Check file type
        is_tira = isfield(data, 'succ_low_all_methods') && isfield(data, 'succ_up_all_methods') && isfield(data, 'methods');
        is_nnv = contains(files(i).name, 'NNV');
        is_cora = contains(files(i).name, 'CORA') || isfield(data, 'final_reachable_set');
        
        if is_tira
            % TIRA data
            all_succ_low{end+1} = data.succ_low_all_methods;
            all_succ_up{end+1} = data.succ_up_all_methods;
            all_t_points{end+1} = data.t_points;
            all_methods{end+1} = data.methods;
            all_n_methods(end+1) = data.n_methods;
            all_n_x(end+1) = data.n_x;
            all_final_sets{end+1} = [];
        elseif is_nnv
            % NNV data (assuming structure similar to TIRA or with final_states)
            if isfield(data, 'succ_low_all_methods') && isfield(data, 'succ_up_all_methods')
                all_succ_low{end+1} = data.succ_low_all_methods;
                all_succ_up{end+1} = data.succ_up_all_methods;
            else
                all_succ_low{end+1} = nan(data.n_x, 1, 1); % Placeholder if missing
                all_succ_up{end+1} = nan(data.n_x, 1, 1);
            end
            all_t_points{end+1} = data.t_points;
            all_methods{end+1} = [5]; % Method index 5 for NNV
            all_n_methods(end+1) = 1;
            all_n_x(end+1) = data.n_x;
            all_final_sets{end+1} = [];
        elseif is_cora
            % CORA data
            if isfield(data, 'succ_low_all_methods') && isfield(data, 'succ_up_all_methods')
                all_succ_low{end+1} = data.succ_low_all_methods;
                all_succ_up{end+1} = data.succ_up_all_methods;
            elseif isfield(data, 'final_reachable_set')
                final_interval = interval(data.final_reachable_set);
                succ_low = final_interval.inf;
                succ_up = final_interval.sup;
                all_succ_low{end+1} = reshape(succ_low, [size(succ_low, 1), 1, 1]); % Reshape for consistency
                all_succ_up{end+1} = reshape(succ_up, [size(succ_up, 1), 1, 1]);
            else
                all_succ_low{end+1} = nan(data.n_x, 1, 1); % Placeholder if missing
                all_succ_up{end+1} = nan(data.n_x, 1, 1);
            end
            if isfield(data, 't_points')
                all_t_points{end+1} = data.t_points;
            else
                all_t_points{end+1} = [data.tFinal]; % Use tFinal if t_points unavailable
            end
            if isfield(data, 'methods')
                all_methods{end+1} = data.methods; % Use if present (e.g., [6] for CORA)
            else
                all_methods{end+1} = [6]; % Method index 6 for CORA
            end
            if isfield(data, 'n_methods')
                all_n_methods(end+1) = data.n_methods;
            else
                all_n_methods(end+1) = 1;
            end
            if isfield(data, 'n_x')
                all_n_x(end+1) = data.n_x;
            elseif isfield(data, 'dim')
                all_n_x(end+1) = data.dim;
            else
                all_n_x(end+1) = 5; % Default assumption
            end
            if isfield(data, 'final_reachable_set')
                all_final_sets{end+1} = data.final_reachable_set;
            else
                all_final_sets{end+1} = [];
            end
        else
            warning('Unrecognized file type for %s. Skipping.', files(i).name);
            continue;
        end
        % Handle random successors
        if isfield(data, 'rand_succ')
            all_rand_succ{end+1} = data.rand_succ;
        elseif isfield(data, 'final_states')
            all_rand_succ{end+1} = data.final_states;
        elseif isfield(data, 'final_states_sampled')
            all_rand_succ{end+1} = data.final_states_sampled;
        else
            all_rand_succ{end+1} = zeros(all_n_x(end), 0); % Default empty
        end
    end

    % Verify consistency
    if length(unique(all_n_x)) > 1 || length(unique(all_n_methods)) > 1
        warning('Inconsistent state or method dimensions across files. Using first file''s dimensions.');
    end
    n_x = all_n_x(1);
    n_methods = max(all_n_methods);

    %% Plotting
    if n_x == 5
        plot_pairs = [1 2; 3 4; 4 5];
        for i = 1:size(plot_pairs, 1)
            figure;
            hold on;
            grid on;
            idx1 = plot_pairs(i, 1);
            idx2 = plot_pairs(i, 2);

            % Plot random successors from all runs
            for j = 1:length(all_rand_succ)
                scatter(all_rand_succ{j}(idx1, :), all_rand_succ{j}(idx2, :), 5, 'k', 'filled');
            end

            % Plot last reachable sets for each file
            handles = [];
            proxy_handles = [];
            legends = {};
            for j = 1:length(files)
                % Extract approach from filename
                approach_tokens = regexp(files(j).name, '_(initial|incremental)_', 'tokens');
                if isempty(approach_tokens)
                    if contains(files(j).name, 'CORA')
                        approach = 'CORA';
                    else
                        warning('No approach detected in file %s. Skipping.', files(j).name);
                        continue;
                    end
                else
                    approach = approach_tokens{1}{1};
                end
                file_methods = all_methods{j}; % Methods from the current file
                % Check file type
                is_nnv = contains(files(j).name, 'NNV');
                is_cora = strcmp(approach, 'CORA');
                if is_nnv
                    % Handle both initial and incremental approaches for NNV
                    for app = {'initial', 'incremental'}
                        app_str = app{1};
                        if strcmp(app_str, approach) || all(isnan(all_succ_low{j}(idx1, :, :))) % Plot if match or force for missing data
                            for m = 3:3 % NNV is method 3
                                method_idx = find(file_methods == m + 2); % 5 for NNV
                                if ~isempty(method_idx)
                                    k = length(all_t_points{j}); % Last time step
                                    x_min = all_succ_low{j}(idx1, k, method_idx);
                                    y_min = all_succ_low{j}(idx2, k, method_idx);
                                    width = all_succ_up{j}(idx1, k, method_idx) - x_min;
                                    height = all_succ_up{j}(idx2, k, method_idx) - y_min;
                                    % Debug data shape and validity
                                    if any(isnan([x_min, y_min, width, height]))
                                        fprintf('Invalid data for file %s, approach %s, method %s at t=%d: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', ...
                                                files(j).name, app_str, method_names{m}, k, x_min, y_min, width, height);
                                        fprintf('succ_low shape: %s, succ_up shape: %s\n', mat2str(size(all_succ_low{j})), mat2str(size(all_succ_up{j})));
                                        if k > 1
                                            k = k - 1; % Try previous time step
                                            x_min = all_succ_low{j}(idx1, k, method_idx);
                                            y_min = all_succ_low{j}(idx2, k, method_idx);
                                            width = all_succ_up{j}(idx1, k, method_idx) - x_min;
                                            height = all_succ_up{j}(idx2, k, method_idx) - y_min;
                                            fprintf('Trying t=%d: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', k, x_min, y_min, width, height);
                                        end
                                    end
                                    % Validate position values
                                    if ~all(isfinite([x_min, y_min, width, height])) || any(isnan([x_min, y_min, width, height])) || width <= 0 || height <= 0
                                        fprintf('Skipping invalid rectangle for file %s, approach %s, method %s: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', ...
                                                files(j).name, app_str, method_names{m}, x_min, y_min, width, height);
                                        continue;
                                    end
                                    if strcmp(app_str, 'initial')
                                        key = 'NNV2.0 Star Set';
                                        legend_str = 'NNV2.0 Star Set';
                                    else
                                        key = sprintf('%s %s', app_str, 'NNV Star Set');
                                        legend_str = sprintf('%s (%s)', method_names{m}, app_str);
                                    end
                                    color = color_map(key);
                                    line_width = 2; % Line width for all the boxes
                                    h = rectangle('Position', [x_min, y_min, width, height], ...
                                                  'EdgeColor', color, 'LineWidth', line_width, 'LineStyle', '-');
                                    handles = [handles, h];
                                    h_proxy = plot(nan, nan, 'Color', color, 'LineWidth', line_width, 'LineStyle', '-', 'Visible', 'off');
                                    proxy_handles = [proxy_handles, h_proxy];
                                    legends{end+1} = legend_str;
                                end
                            end
                        end
                    end
                elseif is_cora
                    % Handle CORA (no initial/incremental, just CORA)
                    for m = 4:4 % CORA is method 4
                        method_idx = find(file_methods == m + 2); % 6 for CORA
                        if ~isempty(method_idx)
                            k = length(all_t_points{j}); % Last time step
                            x_min = all_succ_low{j}(idx1, k, method_idx);
                            y_min = all_succ_low{j}(idx2, k, method_idx);
                            width = all_succ_up{j}(idx1, k, method_idx) - x_min;
                            height = all_succ_up{j}(idx2, k, method_idx) - y_min;
                            % Debug data shape and validity
                            if any(isnan([x_min, y_min, width, height]))
                                fprintf('Invalid data for file %s, approach %s, method %s at t=%d: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', ...
                                        files(j).name, approach, method_names{m}, k, x_min, y_min, width, height);
                                        fprintf('succ_low shape: %s, succ_up shape: %s\n', mat2str(size(all_succ_low{j})), mat2str(size(all_succ_up{j})));
                                        if k > 1
                                            k = k - 1; % Try previous time step
                                            x_min = all_succ_low{j}(idx1, k, method_idx);
                                            y_min = all_succ_low{j}(idx2, k, method_idx);
                                            width = all_succ_up{j}(idx1, k, method_idx) - x_min;
                                            height = all_succ_up{j}(idx2, k, method_idx) - y_min;
                                            fprintf('Trying t=%d: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', k, x_min, y_min, width, height);
                                        end
                            end
                            % Validate position values
                            if ~all(isfinite([x_min, y_min, width, height])) || any(isnan([x_min, y_min, width, height])) || width <= 0 || height <= 0
                                fprintf('Skipping invalid rectangle for file %s, approach %s, method %s: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', ...
                                        files(j).name, approach, method_names{m}, x_min, y_min, width, height);
                                continue;
                            end
                            key = 'CORA Zonotope';
                            color = color_map(key);
                            line_width = 2; % Line width for all the boxes
                            if ~isempty(all_final_sets{j})
                                h = plot(all_final_sets{j}, [idx1, idx2], 'EdgeColor', color, 'LineWidth', line_width);
                            else
                                h = rectangle('Position', [x_min, y_min, width, height], ...
                                              'EdgeColor', color, 'LineWidth', line_width, 'LineStyle', '-');
                            end
                            handles = [handles, h];
                            h_proxy = plot(nan, nan, 'Color', color, 'LineWidth', line_width, 'LineStyle', '-', 'Visible', 'off');
                            proxy_handles = [proxy_handles, h_proxy];
                            legends{end+1} = method_names{m};
                        end
                    end
                else
                    % Handle TIRA files with their methods
                    for m = 1:2 % TIRA methods 1 and 2
                        method_value = find(file_methods == m + 2); % 3 and 4 for TIRA
                        if ~isempty(method_value)
                            method_idx = method_value(1); % Take the first match
                            k = length(all_t_points{j}); % Last time step
                            x_min = all_succ_low{j}(idx1, k, method_idx);
                            y_min = all_succ_low{j}(idx2, k, method_idx);
                            width = all_succ_up{j}(idx1, k, method_idx) - x_min;
                            height = all_succ_up{j}(idx2, k, method_idx) - y_min;
                            % Validate position values
                            if ~all(isfinite([x_min, y_min, width, height])) || any(isnan([x_min, y_min, width, height])) || width <= 0 || height <= 0
                                fprintf('Skipping invalid rectangle for file %s, approach %s, method %s: x_min=%.2f, y_min=%.2f, width=%.2f, height=%.2f\n', ...
                                        files(j).name, approach, method_names{m}, x_min, y_min, width, height);
                                continue;
                            end
                            if strcmp(approach, 'initial')
                                if m == 1
                                    key = 'single-step Mixed-Monotonicity';
                                elseif m == 2
                                    key = 'single-step Sampled-Data Mixed-Monotonicity';
                                end
                                legend_str = sprintf('%s (single-step)', method_names{m});
                            else
                                key = sprintf('%s %s', approach, method_names{m});
                                legend_str = sprintf('%s (%s)', method_names{m}, approach);
                            end
                            color = color_map(key);
                            line_width = 2; % Line width for all the boxes
                            if strcmp(key, 'incremental Mixed-Monotonicity')
                                line_width = 8; % Special thicker line for green box
                            end
                            h = rectangle('Position', [x_min, y_min, width, height], ...
                                          'EdgeColor', color, 'LineWidth', line_width, 'LineStyle', '-');
                            handles = [handles, h];
                            h_proxy = plot(nan, nan, 'Color', color, 'LineWidth', line_width, 'LineStyle', '-', 'Visible', 'off');
                            proxy_handles = [proxy_handles, h_proxy];
                            legends{end+1} = legend_str;
                        end
                    end
                end
            end

            % Add labels and legend only if there are valid handles
            if ~isempty(proxy_handles) && length(proxy_handles) == length(legends)
                xlabel(['$x_', num2str(idx1), '$'], 'Interpreter', 'Latex', 'FontSize', 20);
                ylabel(['$x_', num2str(idx2), '$'], 'Interpreter', 'Latex', 'FontSize', 20);
                title(['$x_', num2str(idx1), '$ vs. $x_', num2str(idx2), '$'], 'Interpreter', 'Latex', 'FontSize', 16);
                legend(proxy_handles, legends, 'Location', 'southeast');
            else
                warning('No valid rectangles or mismatched handles/legends for this plot. Skipping legend.');
            end
            hold off;
        end
    else
        warning('Plotting is set up only for systems with 5 states.');
    end
end