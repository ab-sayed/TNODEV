% Tool Paper:
%   "Add Title here"
%
% Authors:
%   Abdelrahman Sayed Sayed, <abdelrahman.ibrahim -AT- univ-eiffel.fr>, COSYS-ESTAS, Univ Gustave Eiffel
%   Pierre-Jean Meyer, <pierre-jean.meyer -AT- univ-eiffel.fr>, COSYS-ESTAS, Univ Gustave Eiffel
%   Mohamed Ghazel, <mohamed.ghazel -AT- univ-eiffel.fr>, COSYS-ESTAS, Univ Gustave Eiffel
%
% Date: 20 October 2025
% Last update: 16 March 2026 
% Last revision: XX XX 2026

%% V1.5

%------------- BEGIN CODE V1.5 --------------

clear all; close all; clc;

%%% ==================================================================================
%   Verifier.m - Falsification, Iterative Verification, and Refinement with Heuristics
%   Systems: Spiral_non (2D) | FPA (5D) | ACC (8D Hybrid NNCS)
%   Prerequisites: CORA (Reachable tube bounds) | NNV2.0 (ACC & MNIST) |
%   RA Methods:
%           1. Mixed-Monotonicity (Single-step)
%           2. Sampled-Data Mixed-Monotonicity (Single-step)
%           3. Mixed-Monotonicity (Boundary)
%           4. Sampled-Data Mixed-Monotonicity (Boundary)
%%% ===================================================================================

addpath('../OA_methods')
addpath('../Utilities')
addpath('./') % Add current directory for utility functions

%%%  -------------------------------------------------------------------
%  USER CONFIGURATION - EDIT ONLY THIS BLOCK
%%%  -------------------------------------------------------------------

% === 1. SYSTEM SELECTION ===
% system_choice = 14;   % FPA System
% system_choice = 15;   % Spiral_non System
% system_choice = 16;   % MNIST
system_choice = 17;   % ACC System

% === 2. REFINEMENT HEURISTIC CHOICE ===
% Options: 'naive', 'most-sensitive-input-radius', 'interval-norm-gradient'
input_split_heuristic = 'naive';

% =========================================================================
%                     HYBRID NNCS DISPATCHER (ACC)
% =========================================================================
if system_choice == 17
    fprintf('=== Starting Hybrid NNCS Verification Example ===\n');
    fprintf('System: Adaptive Cruise Control (ACC) - 8D\n');
    fprintf('Heuristic: %s\n\n', input_split_heuristic);
    
    % Add the Examples folder containing the ACC files to the path so MATLAB can find the specific mat files 
    addpath(genpath(fullfile(pwd, 'Examples')));
    
    % Pass the user's heuristic choice directly into your optimized ACC function
    reach_acc_TNODEV(input_split_heuristic);
    
    % Stop execution here! The ACC function handles its own specific Star plotting.
    return; 
end

% =========================================================================
%               PURE neural ODE SYSTEM SETUP (FPA / Spiral_non) 
% =========================================================================
node_params.input_split_heuristic = input_split_heuristic;

% === 1. INITIAL SET ===
% Spiral_non (2D)
x0_spiral     = [2.0; 0.0];            % nODE input set center
radius_spiral = 0.2;                   % Initial radius
timeStep_spiral = 0.01;                % CORA and TIRA time step
tFinal_spiral   = 1.0;                 % CORA and TIRA final time

% FPA (5D)
x0_fpa     = [0, -0.58587, 0.8, 0.52323, 0.7]';
radius_fpa = 0.01;
timeStep_fpa = 0.05;                   % CORA and TIRA time step
tFinal_fpa   = 2.0;                    % CORA and TIRA final time

% Auto-select based on system_choice
if system_choice == 15
    x0             = x0_spiral;
    % Initial_radius = radius_spiral;
    Initial_radius = radius_spiral * ones(length(x0), 1);
    system_name    = 'spiral_non';
    cora_params.timeStep = timeStep_spiral;
    cora_params.tFinal   = tFinal_spiral;
    t_init_TIRA          = 0;
    t_final_TIRA         = tFinal_spiral;
    timeStep_TIRA        = timeStep_spiral;
elseif system_choice == 14
    x0             = x0_fpa;
    % Initial_radius = radius_fpa;
    Initial_radius = radius_fpa * ones(length(x0), 1);
    system_name    = 'fpa';
    cora_params.timeStep = timeStep_fpa;
    cora_params.tFinal   = tFinal_fpa;
    t_init_TIRA          = 0;
    t_final_TIRA         = tFinal_fpa;
    timeStep_TIRA        = timeStep_fpa;
else
    error('Invalid system_choice. Use 14 (FPA) or 15 (Spiral_non).');
end

% === 2. CORA PARAMETERS (for Reachable tube bounds) ===
cora_params.taylorTerms  = 2;      % Taylor terms for nonlinear approximation
cora_params.zonotopeOrder = 20;    % Zonotope order for set representation
cora_params.alg          = 'lin';  % Linear approximation
cora_params.tensorOrder  = 2;      % Tensor order for nonlinear dynamics --> "check what will happen if I increase this"

% === 3. TIRA PARAMETERS (for nODE reachability @NODE_RA_New.m) ===
node_params.system_choice = system_choice;
node_params.x0 = x0;
node_params.Initial_radius = Initial_radius;
node_params.t_final = t_final_TIRA;
node_params.timeStep = timeStep_TIRA;
node_params.plot_last_only = true;
node_params.sample_succ_number = 1000; %--> check PJ comment about using the falsification to determine this number

% === 4. SAFE SET (USER-ADJUSTABLE) ===  --> Remove these examples at the end
% and leave it for the User to define it or maybe put just one SAFT SET and
% mention next to it that it's adjustable

% FIX to Ensure Safe Set dimensions match the system dimensions
n_sys = length(x0);

if system_choice == 15 % Spiral (2D)
    % Example 1: Safety verified for all OA methods 
    % node_params.safe_inf = [-1.8; 0.6];   % lower-left corner (x1, x2)
    % node_params.safe_sup = [0.7; 2.8];   % upper-right corner (x1, x2)
   
    % % Example 2: Safety violated for some methods
    % node_params.safe_inf = [-1.3; 0.95];   % [x1_low, x2_low]
    % node_params.safe_sup = [0.25; 2.45]; % [x1_up,  x2_up]
   
    % Example 3: Safety violated for some methods
    % node_params.safe_inf = [-1; 1.2];   % [x1_low, x2_low]
    % node_params.safe_sup = [0.3; 2];    % [x1_up, x2_up]

    % Example 4: Safety violated for some methods
    node_params.safe_inf = [-2; 1.2];   % [x1_low, x2_low]
    node_params.safe_sup = [0.1; 5];    % [x1_up, x2_up]

    % Example 5: Safety violated --> counter example works here 
    % node_params.safe_inf = [-3; 1.5];   % [x1_low, x2_low]
    % node_params.safe_sup = [0; 3]; % [x1_up,  x2_up]

elseif system_choice == 14 % FPA (5D)
    
    % This set goes into verification and it can't be falsified --> However it won't
    % conclude as I am setting finite values only for the x1-x2 and disregarding the
    % rest of the dimensions !!
    % node_params.safe_inf = [-1.285; -2; -Inf; -Inf; -Inf];
    % node_params.safe_sup = [ -0.5;  1;  Inf;  Inf;  Inf];

    % node_params.safe_inf = [-1.4;  -10; -10; -10; -10];
    % node_params.safe_sup = [ 10;   10;  10;  0.0;  10];

    % node_params.safe_inf = [-0; -2; -2; 0; -2]; 
    % node_params.safe_sup = [ -2;  2;  2; 0;  2];
    
    % Falsified Example
    % node_params.safe_inf = [-10; -10; -10; -10; -10];
    % node_params.safe_sup = [ 10;  10;  10; 0; 10];

    % FPA Example 6: 5D safe set (PJ) => safe without refinement
    % node_params.safe_inf = [-1.3; -0.7;-0.9;0.3;2.3];
    % node_params.safe_sup = [-1.2;-0.5;-0.7;0.4;2.5];
    
    % FPA Example that goes into Refinement
    % 1 Refinement only 
    % node_params.safe_inf = [-1.3; -0.7;-0.75;0.35;2.38]; % [x1_low, x2_low, ...]
    % node_params.safe_sup = [-1.2;-0.55;-0.72;0.38;2.48];  % [x1_up,  x2_up, ...]
    
    % Refinement iteration ex.1 --> WORKING @ 2.07 minutes for naive / @ 2.23 minutes 
    % for most-sensitive-input-radius / @ 59.75 seconds for interval-norm-gradient
    % node_params.safe_inf = [-1.29; -0.7;-0.75;0.35;2.38]; % [x1_low, x2_low, ...]
    % node_params.safe_sup = [-1.23;-0.59;-0.72;0.38;2.46];  % [x1_up,  x2_up, ...]

    % Refinement iteration ex.2 --> WORKING @ 35 minutes for naive with 343 iterations / 
    % @39.92 minutes for most-sensitive-input-radius with 343 iterations /
    % Tried with interval-norm-gradient and it has been running for more than 12 hrs. and 
    % reached 1850 without any signs of concluding 
    % node_params.safe_inf = [-1.29; -0.68;-0.74;0.35;2.38]; % [x1_low, x2_low, ...]
    % node_params.safe_sup = [-1.23;-0.59;-0.72;0.37;2.45];  % [x1_up,  x2_up, ...]
end

% Validate dimensions
if length(node_params.safe_inf) ~= n_sys
    error('Dimension mismatch: Safe set has %d dims, but system has %d.', length(node_params.safe_inf), n_sys);
end

% === 5. VERIFICATION LOOP PARAMETERS ===
MAX_ITER = 5000;     %--> "check this crtiteria either we conclude based on that or a time out with a defined time for example 45 mins."

% === 6. PLOTTING CONTROL  ===  --> Re-check cause of big changes with V1.2 Origine
plot_control.show_figures = true;    % Show figures during execution
plot_control.save_final_plot = true; % Simplified: save if verified or falsified
% New Selector:
plot_control.verified_set_style = 'all'; 
% Options: 
%   'all'   -> Plot individual reachable sets for every verified subset (Detailed)
%   'union --> Interval Hull' -> Plot the union of all verified reachable subsets (Clean)
%   'true_union' -> Plot filled polygon of the exact geometric union (Cleanest)

% =========================================================================
fprintf('=== Starting Iterative Verification Analysis ===\n');
fprintf('System: %s (choice=%d)\n', system_name, system_choice);
fprintf('Initial set: center = [%s], radius = %.3f\n', ...
        strjoin(arrayfun(@(x) sprintf('%.3f', x), x0, 'UniformOutput', false), ', '), ...
        max(Initial_radius));
fprintf('TIRA: t = [%.2f, %.2f], step = %.3f\n', t_init_TIRA, t_final_TIRA, timeStep_TIRA);
fprintf('CORA: tFinal = %.2f\n\n', cora_params.tFinal);

%% ------------------------------------------------------------------------
%   INITIALIZATION
% -------------------------------------------------------------------------

tic; % Start timer for total VERDICT time

% Queue of input sets to verify: {x_center, radius}
verification_queue = {{x0, Initial_radius}};

% Results tracking
num_verified = 0;
num_falsified = 0;
num_unknown = 1;

% Global flag for safety
overall_safe = true;
falsified_example = [];
falsified_initial_point = [];
verified_initial_sets = {}; % <--Store OA boxes ([center, radius]) of the initial sets that were proven safe

% Pre-compute CORA bounds once
fprintf('PART 1: Computing Overall Reachable Tube Bounds (CORA)...\n');
cora_full_params                = cora_params;
cora_full_params.x0             = x0;
cora_full_params.Initial_radius = Initial_radius;

if system_choice == 14
    reachable_tube_bounds = fpa_CORA_RT(cora_full_params);
elseif system_choice == 15
    reachable_tube_bounds = spiral_non_CORA_RT(cora_full_params);
elseif system_choice == 17
    reachable_tube_bounds = acc_CORA_RT(cora_full_params);
end
fprintf('PART 1 completed.\n\n');

% Pre-compute Jacobian Bounds once, as they depend on the full CORA reachable tube
fprintf('PART 2: Computing Jacobian Bounds...\n');
a = reachable_tube_bounds.lb;
b = reachable_tube_bounds.ub;
[J_lb, J_ub] = Jacob_bounds_element_wise(a, b, system_choice);
fprintf('PART 2 completed.\n\n');

% Pass Jacobians to UP_Jacobian_Bounds.m
fprintf('PART 3: Passing Jacobian bounds via globals...\n');
global Jacobian_x_low Jacobian_x_up system_choice
Jacobian_x_low = J_lb;
Jacobian_x_up  = J_ub;
system_choice = system_choice;

[~, ~, ~, ~] = UP_Jacobian_Bounds(t_init_TIRA, t_final_TIRA, J_lb, J_ub, [], []);
fprintf('PART 3 completed.\n\n');

%% -----------------------------------------------------------------------------
%   MAIN VERIFICATION LOOP (1. Falsification, 2. Verification , 3. Refinement)
% ----------------------------------------------------------------------------

% ----------------------------------------------------------------------------
%   INITIAL FALSIFICATION STEP
% ----------------------------------------------------------------------------

fprintf('PART 4: Initial Falsification Attempt...\n');
% check_dims = size(node_params.safe_inf, 1);
check_dims = length(node_params.safe_inf);

% Generate random samples from the FULL initial input set
num_falsification_samples = 1000;
initial_samples = node_params.x0 - node_params.Initial_radius + ...
                  2 * node_params.Initial_radius .* rand(length(node_params.x0), num_falsification_samples);

% Simulate trajectories for these samples
final_samples = zeros(check_dims, num_falsification_samples);
global g_sensitivity_bounds_method;
parameters = get_solver_parameters(length(node_params.x0), 0, g_sensitivity_bounds_method);
ode_solver = parameters.ode_solver;
ode_options = parameters.ode_options;

% Fix for anonymous functions and global scope
% We must declare 'system_choice' as global here so the handle can capture it.
global system_choice; 
% Create the function handle for the ODE solver. This handle now "closes over"
% or "captures" the value of system_choice from the workspace where it is defined.
ode_func = @(t,x) System_description(t,x,[]);


for i = 1:num_falsification_samples
    x0_rand = initial_samples(:, i);
    [~, x_traj] = ode_solver(@(t,x) System_description(t,x,[]), [t_init_TIRA, t_final_TIRA], x0_rand, ode_options);
    final_samples(:,i) = x_traj(end, 1:check_dims)';
end

% Check if any sample violates the safe set
violation_indices = find(any(final_samples < node_params.safe_inf | final_samples > node_params.safe_sup, 1));

if ~isempty(violation_indices)
    first_violation_idx = violation_indices(1);
    overall_safe = false;
    falsified_example = final_samples(:, first_violation_idx);
    falsified_initial_point = initial_samples(:, first_violation_idx);
    fprintf('  FALSIFIED! Counter-example found from initial sampling.\n');
    % Use generic string printing for N-D points
    fprintf('  Initial point: [%s]\n', num2str(falsified_initial_point', '%.4f '));
    fprintf('  Final point:   [%s]\n', num2str(falsified_example', '%.4f '));
else
    fprintf('  No counter-example found in initial falsification.\n');
end

fprintf('PART 4 completed.\n\n');

% ----------------------------------------------------------------------------
%    MAIN VERIFICATION & REFINEMENT LOOP
% ----------------------------------------------------------------------------
fprintf('PART 5: Verification and Refinement based Heuristics Loop...\n');

iter = 0;
if overall_safe % Proceed only if not already falsified
    while ~isempty(verification_queue) && iter < MAX_ITER
        iter = iter + 1;
        fprintf('--- ITERATION %d: Queue size = %d ---\n', iter, length(verification_queue));

        % Pop the next set from the queue
        current_set = verification_queue{1};
        verification_queue(1) = [];
        x_i = current_set{1};
        r_i = current_set{2};

        if isscalar(r_i)
            r_i = r_i * ones(length(x_i), 1);
        else
            r_i = r_i(:);
        end

        fprintf('  Calling NODE_RA_New for set with center [%s] and radius %.4f\n', num2str(x_i', '%.4f '), max(r_i));
        % fprintf('  Calling NODE_RA_New for set with center [%.4f, %.4f] and radius %.4f\n', x_i(1), x_i(2), max(r_i));

        % Build NODE_RA_New.m input for the current subset
        node_params_subset                = node_params;
        node_params_subset.x0             = x_i;
        node_params_subset.Initial_radius = r_i;

        % Call NODE_RA_New.m
        reachability_results = NODE_RA_New(node_params_subset);

        % 1. Verification Check (check if all OAs/their union are fully contained in the
        % safe set)

        % ======================================================================
        % Intersection OF ALL 4 OVER-APPROXIMATIONS (NOW COMPUTED IN NODE_RA_New.m)
        % ======================================================================

        intersect_low = reachability_results.intersect_low; % <-- Read from NODE_RA_New output
        intersect_up  = reachability_results.intersect_up;  % <-- Read from NODE_RA_New output
    
        % Check ALL dimensions against safe set
        low_ok = all(intersect_low >= node_params.safe_inf);
        up_ok = all(intersect_up  <= node_params.safe_sup);

        if low_ok && up_ok
            fprintf('  PROVEN SAFE: Intersection of all 4 OAs is within the safe set.\n');
            % verified_initial_sets{end+1} = {x_i, r_i}; % <-- when a set is proven safe, add its definition to our new list. 
            verified_initial_sets{end+1} = {x_i, r_i, intersect_low, intersect_up}; % Store center, radius, and intersection bounds for this verified subset to avoid the un-necessary re-computations in FIGURE 1
            num_verified = num_verified + 1;
            num_unknown = num_unknown - 1;
            continue;
        else
            fprintf('  NOT PROVEN: Intersection of all 4 OAs violates safe set. Refining...\n');
   
            % 2. Refinement of input sets (Refine/Split using selected heuristic)
        
            split_dim = [];     % initialized as empty
    
            % Compute heuristic for refinement/splitting
            switch node_params.input_split_heuristic
                case 'naive'
                    % Refine/Split the dimension with the largest radius
                    [max_radius, split_dim] = max(r_i);
                    fprintf('  Refinement: Using naive heuristic, splitting dimension %d (radius %.4e).\n', split_dim, max_radius);
                
                case 'most-sensitive-input-radius'
                    % Compute sensitivity using Jacobian bounds
                    % Use the maximum absolute Jacobian value as sensitivity
                    try
                        % Call `Jacob_bounds_element_wise.m` function
                        [J_lb, J_ub] = Jacob_bounds_element_wise(x_i - r_i, x_i + r_i, system_choice);
                        
                        % --- Compute sensitivity safely ---
                        absJ = max(abs(J_lb), abs(J_ub));        % 2�2
                        sens = max(absJ, [], 1);                 % 2�1 
                        sens = max(sens, 1e-10);                 % Avoid zero
                 
                        scores = r_i .* sens;
                        [~, split_dim] = max(scores);
                        
                        fprintf(' Refinement: Using most-sensitive-input-radius heuristic, splitting dimension %d (score = %.4e)\n', ...
                                split_dim, max(scores)); % Check if I can remove max(scores)
                                
                    catch
                        [~, split_dim] = max(r_i);
                        fprintf(' Refinement: Fallback to naive heuristic (Jacob failed: %s), splitting dimension %d\n', split_dim);
                    end
        
                case 'interval-norm-gradient'
                    % Approximate gradient of the output interval norm w.r.t. input dimensions
                    try
                        base_norm = sum(intersect_up - intersect_low);
                        if base_norm <= 0
                            throw(MException('','Base reachable set has zero or negative width')); % Re-check this exception again
                        end
                        
                        grad = zeros(size(x_i));
                        delta = 1e-6;
                        
                        for j = 1:length(x_i)
                            x_pert = x_i;
                            x_pert(j) = x_i(j) + delta;
                            
                            node_params.x0 = x_pert;
                            node_params.Initial_radius = r_i;
                            pert_results = NODE_RA_New(node_params);
                            
                            % NEW SIMPLIFIED CALCULATION:
                            p_low = pert_results.intersect_low;
                            p_up = pert_results.intersect_up;
                                                    
                            pert_norm = sum(p_up - p_low);
                            grad(j) = (pert_norm - base_norm) / delta;
                        end

                      
                        heuristic = abs(grad);
                        if any(isnan(heuristic) | isinf(heuristic) | heuristic <= 0)
                            throw(MException('','Invalid gradient'));
                        end
                        
                        [~, split_dim] = max(heuristic);
                        fprintf(' Refinement: Using interval-norm-gradient heuristic, splitting dimension %d (grad = %.4e)\n', ...
                                split_dim, max(heuristic));  % Check if I can remove max(heuristic)
                                
                    catch
                        [~, split_dim] = max(r_i);
                        fprintf(' Refinement: Fallback to naive heuristic (gradient failed), splitting dimension %d\n', split_dim);
                    end
                    
                otherwise
                    error('Invalid input_split_heuristic: %s', node_params.input_split_heuristic);
            end
    
            % Perform the refinement 
            r_new = r_i;
            r_new(split_dim) = r_i(split_dim) / 2;
        
            x_c1 = x_i;
            x_c1(split_dim) = x_i(split_dim) - r_i(split_dim) / 2;
        
            x_c2 = x_i;
            x_c2(split_dim) = x_i(split_dim) + r_i(split_dim) / 2;
        
            % Add new sets to the queue
            verification_queue{end+1} = {x_c1, r_new};
            verification_queue{end+1} = {x_c2, r_new};
        
            fprintf('  Set REFINED: Split dimension %d into two new sets.\n', split_dim);
            num_unknown = num_unknown - 1 + 2;
        end
    end
end
fprintf('PART 5 completed.\n\n');

% Stop VERDICT timer and get elapsed time --> This is the correct location to
% have it since the time taken for plotting is not related to the algorithm
% concluding a Verdict 
elapsed_time = toc;


% ------------------------------------------------------------------------
%   FINAL PLOTTING AND SAVING
% ------------------------------------------------------------------------

if plot_control.save_final_plot
    fprintf('PART 6: Generating Final_Entire_input_set_Verification_Plot and Saving Data...\n');

    % % Create a single results folder
    %=====================================================================
    % CREATE THE RESULTS FOLDER ONCE
    % =====================================================================
    folder_name = sprintf('FINAL_RESULTS_%s_%s', system_name, datestr(now, 'yyyy-mm-dd_HH-MM-SS'));
    save_dir = fullfile(pwd, folder_name);
    if ~exist(save_dir, 'dir'), mkdir(save_dir); end
    fprintf('  Created results folder:\n    %s\n', save_dir);
    
    % Calculate the R_s OA for the initial input set one last time --> Maybe check if I can pass the one directly from above !!
    node_params_full = node_params;
    node_params_full.x0 = x0;
    node_params_full.Initial_radius = Initial_radius;
    res_full = NODE_RA_New(node_params_full);

    % --- Determine Projections based on System ---
    if system_choice == 14 % FPA (5D)
        % Plot requested projections: (x1,x2), (x3,x4), (x4,x5)
        plot_pairs = {[1 2], [3 4], [4 5]};
    else
        % Default 2D projection (x1,x2)
        plot_pairs = {[1 2]};
    end

    % --- Loop over requested projections ---
    for p_idx = 1:length(plot_pairs)
        dims = plot_pairs{p_idx};
        px = dims(1); py = dims(2);

        fprintf('  Generating Figure Set %d for x%d vs x%d...\n', p_idx, px, py);
    
        % Unrefined Rect Projection
        unrefined_low = res_full.intersect_low;
        unrefined_up  = res_full.intersect_up;
        
        rect_unrefined = [unrefined_low(px), unrefined_low(py), ...
                          unrefined_up(px)-unrefined_low(px), unrefined_up(py)-unrefined_low(py)];

        % Safe Set Projection (Clamp Inf for plotting) --> Main Usage is to ensure X_s is
        % plotted correctly by MATLAB, even if your safety definition includes Infinity.
        % /--> I will probably remove it later as it adds complexity 
        sx_inf = max(node_params.safe_inf(px)); sx_sup = min(node_params.safe_sup(px));
        sy_inf = max(node_params.safe_inf(py)); sy_sup = min(node_params.safe_sup(py));
        safe_x = [sx_inf, sx_sup, sx_sup, sx_inf, sx_inf];
        safe_y = [sy_inf, sy_inf, sy_sup, sy_sup, sy_inf];

        % ===========================================================================================================
        % FIGURE 1: Verified Reachable Set (Union of Verified Subsets or all of them) vs. Entire Initial input set OA 
        % ===========================================================================================================
    
        fig = figure('Color', 'w', 'Visible', plot_control.show_figures, 'Position', [100 100 900 700]);
        hold on; grid on; box on;
        set(gca, 'FontSize', 18, 'TickLabelInterpreter', 'latex');
        k = 1; % final time index

        % 1. Black sampled points (from the full initial set)
        plot(final_samples(px,:), final_samples(py,:), 'k.', 'MarkerSize', 5, 'DisplayName', 'Sampled Trajectories');

        % 2. Plot the Unsafe/Un-VERIFIED Reachable Set (i.e. Entire Initial input set) in Red
              
        % Draw it in Red with a dashed line to indicate "Unsafe/Un-VERIFIED"
        rectangle('Position', rect_unrefined, 'EdgeColor', [0.85 0.33 0.1], 'LineWidth', 2, 'LineStyle', '--');
        h_unrefined = plot(NaN,NaN,'--','Color',[0.85 0.33 0.1],'LineWidth',2, 'DisplayName', 'Unrefined OA (Entire Set)');

        % 3. Plot the Reachable Sets of the VERIFIED subsets
    
        h_int = []; 

        % Initialize variables for 'union' mode calculation
        % union_low = Inf(length(x0), 1); --> check which ones are the correct?
        % union_up = -Inf(length(x0), 1);
        
        % union_low = Inf; % Scalars for plotting min/max
        % union_up = -Inf; % Scalars for plotting min/max

        union_low = [Inf; Inf];  % For 2D projections
        union_up = [-Inf; -Inf]; % For 2D projections
    
        % Prepare for True Union
        total_union_poly = polyshape();

        if ~isempty(verified_initial_sets)
            fprintf('  Computing reachable sets for %d verified subsets...\n', length(verified_initial_sets));
        
            for i = 1:length(verified_initial_sets)
                % Extract subset data
                set_info = verified_initial_sets{i};
                x_sub      = set_info{1};  % <-- reuse from the MAIN VERIFICATION LOOP
                r_sub      = set_info{2};  % <-- reuse
                int_low    = set_info{3};  % <-- reuse
                int_up     = set_info{4};  % <-- reuse
                               
                % Logic for different plotting styles
                if strcmp(plot_control.verified_set_style, 'all')
                    % MODE: ALL - Plot each subset individually
                    rect_dims = [int_low(px), int_low(py), int_up(px)-int_low(px), int_up(py)-int_low(py)];
                    rectangle('Position', rect_dims, 'EdgeColor', [0.4940 0.1840 0.5560], 'LineWidth', 1.5);
                
                elseif strcmp(plot_control.verified_set_style, 'true_union')
                    % MODE: TRUE_UNION 
                    % Create a polyshape for this box
                    % vertices: [x1 y1; x2 y1; x2 y2; x1 y2]
                    x_corners = [int_low(px), int_up(px), int_up(px), int_low(px)];
                    y_corners = [int_low(py), int_low(py), int_up(py), int_up(py)];
                    new_poly = polyshape(x_corners, y_corners);
                    % Merge into the total union
                    total_union_poly = union(total_union_poly, new_poly);    
                
                else
                    % MODE: UNION/Interval Hull - Accumulate global min/max bounds
                    union_low = min(union_low, [int_low(px); int_low(py)]);
                    union_up  = max(union_up,  [int_up(px);  int_up(py)]);
                end
            end
        
            % % Handle drawing for 'union' mode or just creating the legend handle
            if strcmp(plot_control.verified_set_style, 'union')
                 rect_dims = [union_low(1), union_low(2), union_up(1)-union_low(1), union_up(2)-union_low(2)];
                 rectangle('Position', rect_dims, 'EdgeColor', [0.4940 0.1840 0.5560], 'LineWidth', 2);

            elseif strcmp(plot_control.verified_set_style, 'true_union')
                 h_poly = plot(total_union_poly, 'FaceColor', [0.4940 0.1840 0.5560], 'FaceAlpha', 0.6, 'EdgeColor', 'none');
            end
        
            % Create a dummy handle for the legend
            legend_name = 'Verified Reachable Sets';
            if strcmp(plot_control.verified_set_style, 'union')
                legend_name = 'Union (Interval Hull) of Verified Reachable Sets';
            end
    
            if strcmp(plot_control.verified_set_style, 'true_union')
                legend_name = 'True Union of Verified Reachable Sets'; 
            end
            
            h_int = plot(NaN,NaN,'-','Color',[0.4940 0.1840 0.5560],'LineWidth',2, 'DisplayName', legend_name);
        end
    
        % 4. Safe set (thick green)
        % safe_x = [node_params.safe_inf(1), node_params.safe_sup(1), node_params.safe_sup(1), node_params.safe_inf(1), node_params.safe_inf(1)];
        % safe_y = [node_params.safe_inf(2), node_params.safe_inf(2), node_params.safe_sup(2), node_params.safe_sup(2), node_params.safe_inf(2)];
        h_safe = plot(safe_x, safe_y, 'Color',[0 0.8 0], 'LineWidth',2, 'DisplayName','Safe Set');
    
        % 5. Falsified point (if any)
        h_fals = [];
        if ~overall_safe
            plot(falsified_example(px), falsified_example(py), 'rX', 'MarkerSize', 12, 'LineWidth', 2, 'DisplayName', 'Counter-Example');
        end
    
        axis equal;
        xlabel(['$x_' num2str(px) '$'], 'Interpreter','latex','FontSize',20); 
        ylabel(['$x_' num2str(py) '$'], 'Interpreter','latex','FontSize',20);
        title(['Reachable set OA vs Verified Safe Subsets ($x_' num2str(px) ', x_' num2str(py) '$)'], 'Interpreter','latex','FontSize',18);
    
        % xlabel('$x_1$','Interpreter','latex','FontSize',20);
        % ylabel('$x_2$','Interpreter','latex','FontSize',20);
        % title('Reachable set OA for the entire initial input set vs. Verified Safe subsets','Interpreter','latex','FontSize',18);
        
        % 6. Legend Logic
        % Order: Unrefined (Red) -> Verified (Purple) -> Safe (Green) -> CounterEx (Red rX)
        legend_entries = [h_unrefined];
        legend_labels = {'Entire Initial input set'};
        
        if ~isempty(h_int)
            legend_entries = [legend_entries, h_int];
            legend_labels = [legend_labels, {'Union of verified subsets OAs'}];
        end
    
        legend_entries = [legend_entries, h_safe];
        legend_labels = [legend_labels, {'Safe Set'}];
    
        if ~overall_safe && ~isempty(h_fals)
            legend_entries(end+1) = h_fals;
            legend_labels{end+1} = 'Counter-Example';
        end
    
        legend(legend_entries, legend_labels, 'Location', 'northeast', 'Interpreter', 'latex');
        set(legend, 'FontSize', 10, 'FontWeight', 'bold', 'Box', 'on')
    
        % plot_filename_entire = fullfile(save_dir, 'Final_Entire_input_set_Verification_Plot_x%d_x%d', px, py');
        % Dynamic plot
        % 1. Create the dynamic filename string first using sprintf
        filename_str = sprintf('Final_Entire_input_set_Verification_Plot_x%d_x%d', px, py);

        % 2. Combine with the directory path
        plot_filename_entire = fullfile(save_dir, filename_str);

        % Save in multiple formats
        saveas(gcf, [plot_filename_entire, '.png']);
        saveas(gcf, [plot_filename_entire, '.pdf']);
        saveas(gcf, [plot_filename_entire, '.fig']);
        print(gcf, [plot_filename_entire, '.eps'], '-depsc'); % Vector EPS for LaTeX
        print(gcf, [plot_filename_entire, '_highres'], '-dpng', '-r600'); % 600 DPI PNG
        fprintf('Final_Entire_input_set_Verification_Plots saved as(PNG, PDF, FIG, EPS, high-res PNG) in:\n %s\n', plot_filename_entire);
        % fprintf('Final_Entire_input_set_Verification_Plots saved for x%d vs x%d.\n', px, py);
    
        % ================================================================================
        % FIGURE 2: Final Refined Plotting: Initial input set vs. Output reachable set OAs
        % ================================================================================
    
        % Create a new figure with a larger size
        fig = figure('Color', 'w', 'Visible', plot_control.show_figures, 'Position', [100 100 900 700]);
        hold on; grid on; box on;
        set(gca, 'FontSize', 18, 'TickLabelInterpreter', 'latex');
    
        % 1. [INPUT] Plot the initial sets that were proven safe (in blue)
    
        if ~isempty(verified_initial_sets)
            for i = 1:length(verified_initial_sets)
                set_info = verified_initial_sets{i};
                center = set_info{1}; radius = set_info{2};
                rect_pos = [center(px)-radius(px), center(py)-radius(py), 2*radius(px), 2*radius(py)];
                rectangle('Position', rect_pos, 'EdgeColor', 'b', 'FaceColor', [0.8 0.8 1]);
            end
        end
        h_ver_init = patch(NaN, NaN, 'b', 'FaceAlpha', 0.3, 'DisplayName', 'Verified Initial Subsets');

    
        % 2. [INPUT] Plot the original full initial input set boundary (dashed black)
        
        initial_inf = x0 - Initial_radius;
        initial_dims = (x0 + Initial_radius) - initial_inf;
        rectangle('Position', [initial_inf(px), initial_inf(py), initial_dims(px), initial_dims(py)], 'EdgeColor', 'k', 'LineWidth', 2, 'LineStyle', '--');
        h_init = plot(NaN, NaN, 'k--', 'LineWidth', 2, 'DisplayName', 'Original Initial Set');


        % 3. [OUTPUT] Unrefined Reachable Set (Red Dashed)
        
        rectangle('Position', rect_unrefined, 'EdgeColor', [0.85 0.33 0.1], 'LineWidth', 2, 'LineStyle', '--');
        h_unrefined_2 = plot(NaN,NaN,'--','Color',[0.85 0.33 0.1],'LineWidth',2, 'DisplayName', 'Entire Initial input set');


        % 4. [OUTPUT] Verified Reachable Sets (Purple)
        % We directly re-use the calculation from Fig 1 logic (computed above)
        
        if ~isempty(verified_initial_sets)
            if strcmp(plot_control.verified_set_style, 'true_union')
                % Use the poly we calculated in Fig 1
                h_poly_2 = plot(total_union_poly, 'FaceColor', [0.4940 0.1840 0.5560], 'FaceAlpha', 0.6, 'EdgeColor', 'none');
                
            elseif strcmp(plot_control.verified_set_style, 'all')
                % Re-loop to plot individual RS rectangles using stored bounds
                for i = 1:length(verified_initial_sets)
                    set_info = verified_initial_sets{i};
                    int_low  = set_info{3};
                    int_up   = set_info{4};
                    rect_dims = [int_low(px), int_low(py), ...
                                 int_up(px)-int_low(px), int_up(py)-int_low(py)];
                    rectangle('Position', rect_dims, 'EdgeColor', [0.4940 0.1840 0.5560], 'LineWidth', 1.5);
                end 
            else
                 % Union mode (using bounds calculated in Fig 1 block)
                 rect_dims = [union_low(1), union_low(2), union_up(1)-union_low(1), union_up(2)-union_low(2)];
                 rectangle('Position', rect_dims, 'EdgeColor', [0.4940 0.1840 0.5560], 'LineWidth', 2);
            end
        end
        h_ver_rs_2 = plot(NaN,NaN,'-','Color',[0.4940 0.1840 0.5560],'LineWidth',2, 'DisplayName', 'Verified Reachable Sets'); % Union of Verified Subsets OAs
        
        % Black sampled points (from the full initial set)
        plot(final_samples(px,:), final_samples(py,:), 'k.', 'MarkerSize', 5, 'DisplayName', 'Sampled Trajectories');

        % 5. [OUTPUT] Safe Set (Green)
        h_safe_2 = plot(safe_x, safe_y, 'Color',[0 0.8 0], 'LineWidth',2, 'DisplayName','Safe Set');

    
        % 6. Falsified Points (Input and Output if applicable)
        h_fals_in = []; h_fals_out = [];
        if ~overall_safe
            % Input Point
            h_fals_in = plot(falsified_initial_point(1), falsified_initial_point(2), 'bx', 'MarkerSize', 12, 'LineWidth', 2, 'DisplayName', 'Falsifying Input');
            % Output Point
            h_fals_out = plot(falsified_example(1), falsified_example(2), 'rX', 'MarkerSize', 12, 'LineWidth', 2, 'DisplayName', 'Falsifying Output');
        end
    

        axis equal;
        xlabel(['$x_' num2str(px) '$'], 'Interpreter','latex','FontSize',20); 
        ylabel(['$x_' num2str(py) '$'], 'Interpreter','latex','FontSize',20);
        title(['Global View: Refined Initial input set \& Resulting Refined Safe subsets OAs ($x_' num2str(px) ', x_' num2str(py) '$)'],'Interpreter','latex','FontSize',18);
        

        % Legend 2
        legend_entries_2 = [h_init, h_ver_init, h_unrefined_2, h_ver_rs_2, h_safe_2];
        legend_labels_2 = {'Original Initial input Set', 'Verified Initial Subsets', 'Entire Initial input set OA', 'Union of verified subsets OAs', 'Safe Set'};
    
        if ~overall_safe
            if ~isempty(h_fals_in), legend_entries_2(end+1) = h_fals_in; legend_labels_2{end+1} = 'Falsifying Input'; end
            if ~isempty(h_fals_out), legend_entries_2(end+1) = h_fals_out; legend_labels_2{end+1} = 'Falsifying Output'; end
        end
    
        legend(legend_entries_2, legend_labels_2, 'Location', 'northeast', 'Interpreter', 'latex');
        set(legend, 'FontSize', 10, 'FontWeight', 'bold', 'Box', 'on')
        
        % plot_filename_refined = fullfile(save_dir, 'Refined_Safe_Subsets_Plot_x%d_x%d', px, py');
        % Dynamic plot
        % 1. Create the dynamic filename string first using sprintf
        filename_str = sprintf('Refined_Safe_Subsets_Plot_x%d_x%d', px, py);
        
        % 2. Combine with the directory path
        plot_filename_refined = fullfile(save_dir, filename_str);

        % Save in multiple formats
        saveas(gcf, [plot_filename_refined, '.png']);
        saveas(gcf, [plot_filename_refined, '.pdf']);
        saveas(gcf, [plot_filename_refined, '.fig']);
        print(gcf, [plot_filename_refined, '.eps'], '-depsc'); % Vector EPS for LaTeX
        print(gcf, [plot_filename_refined, '_highres'], '-dpng', '-r600'); % 600 DPI PNG
        fprintf('Refined_Safe_Subsets_Plots saved as(PNG, PDF, FIG, EPS, high-res PNG) in:\n %s\n', plot_filename_refined);
    end

        % Save the detailed .mat file
        filename_base = sprintf('reachability_data_sys%d_%s', system_choice, datestr(now, 'yyyy-mm-dd'));
       
     
        save(fullfile(save_dir, [filename_base '.mat']), ...
            'verified_initial_sets', ...
            'falsified_example', 'falsified_initial_point', ...
            'final_samples', ...
            'res_full', ... % Added the result of the Entire Initial input set to the saved data
            'overall_safe', '-v7.3');
    
        fprintf('Final .mat data saved to: %s.mat\n', filename_base);

        % % Also save a simpler summary file %--> ##Check how to save it as .txt file 
        % save(fullfile(save_dir, 'verification_summary.mat'), 'verified_initial_sets', 'falsified_example', 'falsified_initial_point', 'verdict_string', '-v7.3');
        % fprintf('  Saved summary to: verification_summary.mat\n');
    
        fprintf('PART 6 completed.\n\n');
end

%% ------------------------------------------------------------------------
%   FINAL VERDICT & SUMMARY
% -------------------------------------------------------------------------

clear global Jacobian_x_low Jacobian_x_up system_choice_global

% --- Final Verdict ---

is_fully_verified = false;
verdict_string = '';

if ~overall_safe
    verdict_string = 'FALSIFIED! Counter-example found.';
else
    % Simplified clear Logic:
    % If queue is empty, we verified everything, i.e. it means we didn't time out,
    % and we didn't throw anything away. Therefore, the entire volume is safe.
    if isempty(verification_queue)
        is_fully_verified = true;
        verdict_string = 'FULLY VERIFIED (SAFE) for the initial input set.';
    else
        % If queue is not empty, it means we reached MAX_ITER, i.e. Timeout
        verdict_string = sprintf('UNKNOWN (Timeout: %d subsets remain unverified).', length(verification_queue));
    end
end


% --- Final Summary ---
fprintf('\n\n=================================================================\n');
fprintf('               Verification Analysis Complete\n');
fprintf('=================================================================\n\n');
fprintf('--- Overall Summary ---\n');
fprintf('System: %s\n', upper(system_name));
fprintf('Total Iterations: %d\n', iter);
fprintf('Verified Subsets: %d\n', num_verified);
fprintf('Falsified Subsets: %d\n', num_falsified);
fprintf('Remaining Unknown Subsets: %d\n', length(verification_queue)); % Re-check if this is reading the correct number

% Logic to print the elapsed time in seconds (if less than 60 seconds) or minutes 
% (if 60 seconds or more) for easier readability
if elapsed_time < 60
    fprintf('Total Time Taken: %.2f seconds\n', elapsed_time);
else
    fprintf('Total Time Taken: %.2f minutes\n', elapsed_time / 60);
end

fprintf('\nVERDICT: %s\n', verdict_string);
if ~overall_safe, fprintf('  Initial point: [%s]\n  Final point:   [%s]\n', strjoin(arrayfun(@(x) sprintf('%.4f', x), falsified_initial_point, 'UniformOutput', false), ', '), strjoin(arrayfun(@(x) sprintf('%.4f', x), falsified_example, 'UniformOutput', false), ', ')); end

fprintf('\n=================================================================\n');

%------------- END OF CODE V1.5 --------------



