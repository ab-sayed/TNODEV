function run_mnist_iterative_verification()
% Run Iterative Refinement Verification on MNIST
% Supports two modes:
%   1. 'full_network'   : Uses ODELayer_TIRA inside net.reach()
%   2. 'layer_by_layer': Manual propagation layer by layer

    % ================= CONFIGURATION =================
    mode = 'full_network';  % Options: 'full_network' or 'layer_by_layer'
    
    pix  = 80;             % Number of pixels to attack
    numT = 2;             % Number of images to verify
    noise = 0.5/255;      % L_inf noise radius
    MAX_ITER = 1000;        % Max refinement steps per image
    perturbation = 'inf';
    
    % ================= INITIALIZATION =================
    % Add paths
    verifier_root = '/home/ibrahima/Documents/nODE_Verifier/TNODEV';
    addpath(genpath(verifier_root));
    rng(2022);

    % Load Data
    Xall = processMNISTimages('t10k-images.idx3-ubyte');
    Yall = processMNISTlabels('t10k-labels.idx1-ubyte');
    Xall = single(extractdata(Xall)); Yall = single(Yall);
    
    % Build Batch
    XTest = zeros(28,28,1,numT, 'single');
    YTest = zeros(numT,1, 'single');
    for k = 1:numT
        YTest(k) = Yall(k);
        XTest(:,:,:,k) = Xall(:,:,:,k);
    end

    % Load Network Weights & Pre-compute Dynamics
    setup_data = load_and_setup_network(mode); 

    % ================= MAIN LOOP =================
    fprintf('Starting Iterative Verification (Mode: %s)...\n', mode);
    
    results = struct('robust', 0, 'unknown', 0, 'not_robust', 0);
    total_time = 0;

    for i = 1:numT
        fprintf('\n=== Image %d / %d ===\n', i, numT);
        t_img = tic;
        
        % 1. Setup Initial Attack Bounds [lb, ub]
        img_flat = XTest(:,:,:,i)'; % 784x1
        pixels_attack = randperm(784, pix);
        
        [lb_init, ub_init] = create_attack_bounds(img_flat, pixels_attack, noise, perturbation);
        
        % 2. Initialize Queue: {lb, ub}
        queue = {{lb_init, ub_init}};
        
        is_proven_robust = false;
        is_falsified = false; % (Requires actual counter-example finding, we assume safe unless proven otherwise)
        iter_count = 0;
        
        % 3. Refinement Loop
        while ~isempty(queue) && iter_count < MAX_ITER
            iter_count = iter_count + 1;
            
            % Pop next sub-problem
            current_bounds = queue{1};
            queue(1) = [];
            
            lb_curr = current_bounds{1};
            ub_curr = current_bounds{2};
            
            % Create Star for this sub-region
            if max(img_flat) > 1.0
                 inpS = ImageStar(lb_curr, ub_curr); % [0, 255]
            else
                 inpS = ImageStar(lb_curr./255, ub_curr./255); % [0, 1]
            end
            
            % --- PERFORM REACHABILITY (The Core) ---
            try
                if strcmp(mode, 'full_network')
                    % Method 1: Standard NNV Style
                    R_out = setup_data.net.reach(inpS);
                else
                    % Method 2: Layer-by-Layer Style
                    R_out = run_layer_by_layer(inpS, setup_data);
                end
                
                % --- CHECK ROBUSTNESS ---
                res_val = setup_data.net_out.checkRobust(R_out, YTest(i));
                
                if res_val == 1
                    % Safe branch! We don't need to refine this specific box anymore.
                    % Proceed to next item in queue.
                    fprintf('  Iter %d: Sub-region Verified Safe.\n', iter_count);
                else
                    % Unknown/Not Robust -> Need to Split
                    fprintf('  Iter %d: Not Verified. Splitting...\n', iter_count);
                    
                    % Find widest dimension to split
                    % We only look at attacked pixels
                    diff = ub_curr - lb_curr;
                    [max_width, split_idx] = max(diff);
                    
                    if max_width < 1e-6
                        fprintf('  Warning: Intervals too small to split further.\n');
                        continue; 
                    end
                    
                    % Split Logic
                    lb_1 = lb_curr; ub_1 = ub_curr;
                    lb_2 = lb_curr; ub_2 = ub_curr;
                    
                    mid = lb_curr(split_idx) + max_width/2;
                    
                    ub_1(split_idx) = mid; % Left Child
                    lb_2(split_idx) = mid; % Right Child
                    
                    % Add children to queue
                    queue{end+1} = {lb_1, ub_1};
                    queue{end+1} = {lb_2, ub_2};
                end
                
            catch ME
                fprintf('  Error in reachability: %s\n', ME.message);
            end
        end
        
        time_elapsed = toc(t_img);
        total_time = total_time + time_elapsed;
        
        % Final Verdict for Image
        if isempty(queue)
            fprintf('  RESULT: ROBUST (Verified)\n');
            results.robust = results.robust + 1;
        else
            fprintf('  RESULT: UNKNOWN (Timeout after %d iterations)\n', iter_count);
            results.unknown = results.unknown + 1;
        end
    end
    
    % Summary
    fprintf('\n=== SUMMARY ===\n');
    fprintf('Robust: %d\nUnknown: %d\nTotal Time: %.2fs\n', results.robust, results.unknown, total_time);
end

% =========================================================================
% HELPER FUNCTIONS
% =========================================================================

function [lb, ub] = create_attack_bounds(img, pixels, noise, type)
    if max(img) <= 1.0
        imgMax = 1.0; noisePix = noise; 
    else
        imgMax = 255.0; noisePix = noise * 255; 
    end
    
    lb = img; ub = img;
    
    if strcmp(type, 'inf')
        for j = pixels
            ub(j) = min(imgMax, ub(j) + noisePix);
            lb(j) = max(0, lb(j) - noisePix);
        end
    end
end

function data = load_and_setup_network(mode)
    % Common Loading
    load('odecnn_mnist_tiny.mat'); % Wb
    
    % Prepare ODE Dynamics
    w1_ode = Wb{9}; b1_ode = Wb{10}';
    w2_ode = Wb{11}; b2_ode = Wb{12}';
    Aout = w2_ode * w1_ode;
    Bout = w2_ode * b1_ode + b2_ode;
    
    % Pre-compute Matrices (Optimization for NODE_RA V2.8)
    fprintf('Pre-computing Matrices...\n');
    [V, D] = eig(Aout);
    [V_real, D_real] = cdf2rdf(V, D);
    V_inv = inv(V_real);
    B_tilde = V_inv * Bout;
    
    % Build Layers 1-7 (Prefix)
    w1 = permute(Wb{1},[4 3 2 1]); b1 = reshape(Wb{2},[1,1,4]);
    L1 = Conv2DLayer(w1,b1,[0,0,0,0],[1,1],[1,1]);
    w2 = reshape(Wb{3},[1 1 4]); b2 = reshape(Wb{4},[1 1 4]); m2 = reshape(Wb{15},[1 1 4]); v2 = reshape(Wb{16},[1 1 4]);
    L2 = BatchNormalizationLayer('Offset',b2,'Scale',w2,'TrainedMean',m2,'TrainedVariance',v2,'NumChannels',4,'Epsilon',4);
    L3 = ReluLayer;
    w4 = permute(Wb{5},[4 3 2 1]); b4 = reshape(Wb{6},[1,1,4]);
    L4 = Conv2DLayer(w4,b4,[1,1,1,1],[2,2],[1,1]);
    w5 = reshape(Wb{7},[1 1 4]); b5 = reshape(Wb{8},[1 1 4]); m5 = reshape(Wb{18},[1 1 4]); v5 = reshape(Wb{19},[1 1 4]);
    L5 = BatchNormalizationLayer('Offset',b5,'Scale',w5,'TrainedMean',m5,'TrainedVariance',v5,'NumChannels',4,'Epsilon',4);
    L6 = ReluLayer;
    L7 = FlattenLayer; L7.Type = 'nnet.cnn.layer.FlattenLayer';
    
    % Output Layer (Layer 9)
    L9 = FullyConnectedLayer(Wb{13}, Wb{14}');
    net_out = NN({L9});
    
    data.net_prefix = NN({L1,L2,L3,L4,L5,L6,L7});
    data.net_out = net_out;
    data.params_template.V_real = V_real;
    data.params_template.V_inv = V_inv;
    data.params_template.D_real = D_real;
    data.params_template.B_tilde = B_tilde;
    data.params_template.t_final = 1.0;
    data.params_template.timeStep = 0.1;
    data.params_template.system_choice = 16;
    
    if strcmp(mode, 'full_network')
        % Build Full Net with Custom Layer
        L8 = ODELayer_TIRA(Aout, Bout, 1.0, 16);
        % Pass pre-computed props to layer manually to ensure consistency
        L8.V_real = V_real; L8.V_inv = V_inv; L8.D_real = D_real; L8.B_tilde = B_tilde;
        
        data.net = NN({L1,L2,L3,L4,L5,L6,L7,L8,L9});
    end
end

function R_out = run_layer_by_layer(inpS, data)
    % 1. Prefix
    try
        R_prefix = data.net_prefix.reach(inpS, 'approx-star');
    catch
        R_prefix = data.net_prefix.reach(inpS);
    end
    
    % 2. NODE_RA
    % Prepare params
    [lb, ub] = R_prefix.getRanges();
    params = data.params_template;
    params.x0 = 0.5 * (lb + ub);
    params.Initial_radius = 0.5 * (ub - lb);
    params.input_star = R_prefix;
    
    res = NODE_RA(params);
    
    if isfield(res, 'star_set')
        R_node = res.star_set;
    else
        R_node = Star(res.intersect_low, res.intersect_up);
    end
    
    % 3. Output
    R_out = data.net_out.reach(R_node);
end